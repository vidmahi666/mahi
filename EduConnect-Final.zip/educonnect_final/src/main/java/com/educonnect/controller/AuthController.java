package com.educonnect.controller;

import com.educonnect.dto.request.LoginRequest;
import com.educonnect.dto.request.RegisterRequest;
import com.educonnect.dto.response.ApiResponse;
import com.educonnect.dto.response.AuthResponse;
import com.educonnect.service.AuthService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@Slf4j
@RestController
@RequestMapping("/api/auth")
@RequiredArgsConstructor
@Tag(name = "1. Authentication", description = "Register and login endpoints")
public class AuthController {

    private final AuthService authService;

    @PostMapping("/register")
    @Operation(summary = "Register a new user",
               description = "Creates a user account. Role must be one of: STUDENT, TEACHER, ADMIN, PROGRAM_MANAGER, COMPLIANCE_OFFICER, GOVERNMENT_AUDITOR")
    public ResponseEntity<ApiResponse<AuthResponse>> register(
            @Valid @RequestBody RegisterRequest request) {
        log.info("POST /api/auth/register - email={}", request.getEmail());
        return ResponseEntity.status(HttpStatus.CREATED)
                .body(ApiResponse.success(authService.register(request), "User registered successfully"));
    }

    @PostMapping("/login")
    @Operation(summary = "Login and get JWT token",
               description = "Returns a Bearer token. Add it to subsequent requests as: Authorization: Bearer <token>")
    public ResponseEntity<ApiResponse<AuthResponse>> login(
            @Valid @RequestBody LoginRequest request) {
        log.info("POST /api/auth/login - email={}", request.getEmail());
        return ResponseEntity.ok(ApiResponse.success(authService.login(request), "Login successful"));
    }
}
