package com.educonnect.controller;

import com.educonnect.dto.response.ApiResponse;
import com.educonnect.dto.response.StudentResponse;
import com.educonnect.service.StudentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/students")
@RequiredArgsConstructor
@Tag(name = "Students", description = "Student profile management APIs")
public class StudentController {

    private final StudentService studentService;

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','TEACHER','PROGRAM_MANAGER')")
    @Operation(summary = "Get all students")
    public ResponseEntity<ApiResponse<List<StudentResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(studentService.getAllStudents(), "Students retrieved"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get student by ID")
    public ResponseEntity<ApiResponse<StudentResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(studentService.getStudentById(id), "Student retrieved"));
    }

    @GetMapping("/user/{userId}")
    @Operation(summary = "Get student by user ID")
    public ResponseEntity<ApiResponse<StudentResponse>> getByUserId(@PathVariable Long userId) {
        return ResponseEntity.ok(ApiResponse.success(studentService.getStudentByUserId(userId), "Student retrieved"));
    }
}
