package com.educonnect.controller;

import com.educonnect.dto.request.ContentRequest;
import com.educonnect.dto.response.ApiResponse;
import com.educonnect.dto.response.ContentResponse;
import com.educonnect.service.ContentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/content")
@RequiredArgsConstructor
@Tag(name = "Content", description = "Digital learning content APIs")
public class ContentController {

    private final ContentService contentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Upload content")
    public ResponseEntity<ApiResponse<ContentResponse>> upload(@Valid @RequestBody ContentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(contentService.uploadContent(request), "Content uploaded"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get content by ID")
    public ResponseEntity<ApiResponse<ContentResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(contentService.getContentById(id), "Content retrieved"));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get content by course")
    public ResponseEntity<ApiResponse<List<ContentResponse>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(contentService.getContentByCourse(courseId), "Content retrieved"));
    }

    @PostMapping("/{contentId}/access/{studentId}")
    @Operation(summary = "Track content access")
    public ResponseEntity<ApiResponse<Void>> trackAccess(@PathVariable Long contentId, @PathVariable Long studentId) {
        contentService.trackAccess(studentId, contentId);
        return ResponseEntity.ok(ApiResponse.success(null, "Access tracked"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update content")
    public ResponseEntity<ApiResponse<ContentResponse>> update(@PathVariable Long id, @Valid @RequestBody ContentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(contentService.updateContent(id, request), "Content updated"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Archive content")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        contentService.deleteContent(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Content archived"));
    }
}
