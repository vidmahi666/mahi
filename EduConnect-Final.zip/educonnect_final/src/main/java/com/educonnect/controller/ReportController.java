package com.educonnect.controller;

import com.educonnect.dto.response.ApiResponse;
import com.educonnect.entity.Report.ReportScope;
import com.educonnect.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

@RestController
@RequestMapping("/api/reports")
@RequiredArgsConstructor
@Tag(name = "Reports", description = "Reporting and analytics APIs")
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/dashboard")
    @PreAuthorize("hasAnyRole('ADMIN','PROGRAM_MANAGER')")
    @Operation(summary = "Get dashboard metrics")
    public ResponseEntity<ApiResponse<Map<String, Object>>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success(reportService.getDashboardMetrics(), "Dashboard metrics retrieved"));
    }

    @GetMapping("/generate/{scope}")
    @PreAuthorize("hasAnyRole('ADMIN','PROGRAM_MANAGER','COMPLIANCE_OFFICER','GOVERNMENT_AUDITOR')")
    @Operation(summary = "Generate report by scope")
    public ResponseEntity<ApiResponse<Map<String, Object>>> generate(@PathVariable ReportScope scope) {
        return ResponseEntity.ok(ApiResponse.success(reportService.generateReport(scope), "Report generated"));
    }
}
