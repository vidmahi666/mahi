package com.educonnect.service;

import com.educonnect.dto.response.ApiResponse;
import com.educonnect.entity.Report.ReportScope;
import java.util.Map;

public interface ReportService {
    Map<String, Object> generateReport(ReportScope scope);
    Map<String, Object> getDashboardMetrics();
}
