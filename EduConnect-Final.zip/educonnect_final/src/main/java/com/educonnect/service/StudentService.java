package com.educonnect.service;

import com.educonnect.dto.response.StudentResponse;
import java.util.List;

public interface StudentService {
    StudentResponse getStudentById(Long id);
    StudentResponse getStudentByUserId(Long userId);
    List<StudentResponse> getAllStudents();
    StudentResponse updateStudent(Long id, com.educonnect.dto.request.RegisterRequest req);
}
