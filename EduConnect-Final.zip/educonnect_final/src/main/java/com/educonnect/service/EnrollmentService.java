package com.educonnect.service;

import com.educonnect.dto.request.EnrollmentRequest;
import com.educonnect.dto.response.EnrollmentResponse;
import java.util.List;

public interface EnrollmentService {
    EnrollmentResponse enroll(EnrollmentRequest request);
    List<EnrollmentResponse> getEnrollmentsByStudent(Long studentId);
    List<EnrollmentResponse> getEnrollmentsByCourse(Long courseId);
    EnrollmentResponse updateStatus(Long id, String status);
    void unenroll(Long id);
}
