package com.educonnect.service.impl;

import com.educonnect.dto.request.ComplianceRecordRequest;
import com.educonnect.dto.response.ComplianceRecordResponse;
import com.educonnect.entity.ComplianceRecord;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.ComplianceRecordRepository;
import com.educonnect.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepository;

    @Override
    @Transactional
    public ComplianceRecordResponse createRecord(ComplianceRecordRequest request) {
        ComplianceRecord r = ComplianceRecord.builder()
                .entityId(request.getEntityId())
                .type(request.getType())
                .result(request.getResult())
                .notes(request.getNotes())
                .build();
        return mapToResponse(complianceRepository.save(r));
    }

    @Override
    public List<ComplianceRecordResponse> getAllRecords() {
        return complianceRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<ComplianceRecordResponse> getRecordsByEntity(Long entityId) {
        return complianceRepository.findByEntityId(entityId)
                .stream().map(this::mapToResponse).toList();
    }

    private ComplianceRecordResponse mapToResponse(ComplianceRecord r) {
        return ComplianceRecordResponse.builder()
                .complianceId(r.getComplianceId())
                .entityId(r.getEntityId())
                .type(r.getType())
                .result(r.getResult())
                .recordDate(r.getRecordDate())
                .notes(r.getNotes())
                .build();
    }
}
