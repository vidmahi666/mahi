package com.educonnect.service;

import com.educonnect.dto.request.NotificationRequest;
import com.educonnect.dto.response.NotificationResponse;
import java.util.List;

public interface NotificationService {
    NotificationResponse send(NotificationRequest request);
    List<NotificationResponse> getByUser(Long userId);
    NotificationResponse markAsRead(Long notificationId);
    long countUnread(Long userId);
}
