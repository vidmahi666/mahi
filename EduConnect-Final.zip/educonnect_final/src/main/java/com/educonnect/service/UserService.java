package com.educonnect.service;

import com.educonnect.dto.response.UserResponse;
import com.educonnect.entity.Role;
import java.util.List;

public interface UserService {
    List<UserResponse> getAllUsers();
    UserResponse getUserById(Long id);
    List<UserResponse> getUsersByRole(Role role);
    UserResponse updateUserStatus(Long id, String status);
    void deleteUser(Long id);
}
