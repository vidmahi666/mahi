package com.educonnect.service;

import com.educonnect.dto.request.ContentRequest;
import com.educonnect.dto.response.ContentResponse;
import java.util.List;

public interface ContentService {
    ContentResponse uploadContent(ContentRequest request);
    ContentResponse getContentById(Long id);
    List<ContentResponse> getContentByCourse(Long courseId);
    ContentResponse updateContent(Long id, ContentRequest request);
    void deleteContent(Long id);
    void trackAccess(Long studentId, Long contentId);
}
