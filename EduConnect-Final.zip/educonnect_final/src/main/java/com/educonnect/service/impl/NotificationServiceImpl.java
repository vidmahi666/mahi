package com.educonnect.service.impl;

import com.educonnect.dto.request.NotificationRequest;
import com.educonnect.dto.response.NotificationResponse;
import com.educonnect.entity.Notification;
import com.educonnect.entity.User;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.NotificationRepository;
import com.educonnect.repository.UserRepository;
import com.educonnect.service.NotificationService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class NotificationServiceImpl implements NotificationService {

    private final NotificationRepository notificationRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public NotificationResponse send(NotificationRequest request) {
        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));
        Notification notification = Notification.builder()
                .user(user).entityId(request.getEntityId())
                .message(request.getMessage()).category(request.getCategory()).build();
        return mapToResponse(notificationRepository.save(notification));
    }

    @Override
    public List<NotificationResponse> getByUser(Long userId) {
        return notificationRepository.findByUserUserIdOrderByCreatedDateDesc(userId)
                .stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public NotificationResponse markAsRead(Long notificationId) {
        Notification n = notificationRepository.findById(notificationId)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found"));
        n.setStatus(Notification.NotificationStatus.READ);
        return mapToResponse(notificationRepository.save(n));
    }

    @Override
    public long countUnread(Long userId) {
        return notificationRepository.countByUserUserIdAndStatus(userId, Notification.NotificationStatus.UNREAD);
    }

    private NotificationResponse mapToResponse(Notification n) {
        return NotificationResponse.builder()
                .notificationId(n.getNotificationId()).userId(n.getUser().getUserId())
                .entityId(n.getEntityId()).message(n.getMessage())
                .category(n.getCategory()).status(n.getStatus())
                .createdDate(n.getCreatedDate()).build();
    }
}
