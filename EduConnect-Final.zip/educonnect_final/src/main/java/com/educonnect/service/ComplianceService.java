package com.educonnect.service;

import com.educonnect.dto.request.AuditRequest;
import com.educonnect.dto.request.ComplianceRecordRequest;
import com.educonnect.dto.response.AuditResponse;
import com.educonnect.dto.response.ComplianceRecordResponse;
import java.util.List;

public interface ComplianceService {
    ComplianceRecordResponse createRecord(ComplianceRecordRequest request);
    List<ComplianceRecordResponse> getAllRecords();
    List<ComplianceRecordResponse> getRecordsByEntity(Long entityId);
    AuditResponse createAudit(AuditRequest request);
    List<AuditResponse> getAllAudits();
    AuditResponse updateAuditStatus(Long id, String status);
}
