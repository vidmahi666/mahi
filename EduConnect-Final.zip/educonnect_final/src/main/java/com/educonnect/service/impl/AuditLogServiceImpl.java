package com.educonnect.service.impl;

import com.educonnect.entity.AuditLog;
import com.educonnect.entity.User;
import com.educonnect.repository.AuditLogRepository;
import com.educonnect.repository.UserRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogServiceImpl {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository userRepository;

    @Async
    public void log(Long userId, String action, String resource) {
        try {
            User user = userRepository.findById(userId).orElse(null);
            AuditLog auditLog = AuditLog.builder()
                    .user(user).action(action).resource(resource).build();
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.error("Failed to save audit log: {}", e.getMessage());
        }
    }
}
