package com.educonnect.service.impl;

import com.educonnect.dto.response.ApiResponse;
import com.educonnect.entity.Report;
import com.educonnect.entity.Report.ReportScope;
import com.educonnect.repository.*;
import com.educonnect.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final CourseRepository           courseRepository;
    private final EnrollmentRepository       enrollmentRepository;
    private final StudentRepository          studentRepository;
    private final AssessmentRepository       assessmentRepository;
    private final ComplianceRecordRepository complianceRecordRepository;
    private final ReportRepository           reportRepository;

    @Override
    public Map<String, Object> generateReport(ReportScope scope) {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("scope", scope.name());
        metrics.put("generatedAt", LocalDateTime.now().toString());

        switch (scope) {
            case COURSE -> {
                metrics.put("totalCourses", courseRepository.count());
                metrics.put("activeCourses",
                        courseRepository.findByStatus(
                                com.educonnect.entity.Course.CourseStatus.ACTIVE).size());
            }
            case STUDENT -> {
                metrics.put("totalStudents", studentRepository.count());
            }
            case ASSESSMENT -> {
                metrics.put("totalAssessments", assessmentRepository.count());
            }
            case COMPLIANCE -> {
                metrics.put("totalRecords", complianceRecordRepository.count());
            }
            default -> metrics.put("message", "Report generated");
        }

        Report saved = Report.builder()
                .scope(scope)
                .metrics(metrics.toString())
                .generatedBy("system")
                .build();
        reportRepository.save(saved);

        return metrics;
    }

    @Override
    public Map<String, Object> getDashboardMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("totalStudents", studentRepository.count());
        metrics.put("totalCourses", courseRepository.count());
        metrics.put("totalEnrollments", enrollmentRepository.count());
        metrics.put("totalAssessments", assessmentRepository.count());
        metrics.put("complianceRecords", complianceRecordRepository.count());
        metrics.put("generatedAt", LocalDateTime.now().toString());
        return metrics;
    }
}
