package com.educonnect.service;

import com.educonnect.dto.request.LoginRequest;
import com.educonnect.dto.request.RegisterRequest;
import com.educonnect.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
}
