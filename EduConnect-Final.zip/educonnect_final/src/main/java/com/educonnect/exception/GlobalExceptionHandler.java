package com.educonnect.exception;

import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.InternalAuthenticationServiceException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.authorization.AuthorizationDeniedException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpMediaTypeNotSupportedException;
import org.springframework.web.HttpRequestMethodNotAllowedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.context.request.WebRequest;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ── 404 Not Found ─────────────────────────────────────────────
    @ExceptionHandler(ResourceNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(
            ResourceNotFoundException ex, WebRequest req) {
        log.warn("Resource not found: {}", ex.getMessage());
        return build(HttpStatus.NOT_FOUND, ex.getMessage(), req);
    }

    // ── 400 Bad Request ───────────────────────────────────────────
    @ExceptionHandler(BadRequestException.class)
    public ResponseEntity<ErrorResponse> handleBadRequest(
            BadRequestException ex, WebRequest req) {
        log.warn("Bad request: {}", ex.getMessage());
        return build(HttpStatus.BAD_REQUEST, ex.getMessage(), req);
    }

    // ── 400 Validation (field-level) ──────────────────────────────
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<Map<String, Object>> handleValidation(
            MethodArgumentNotValidException ex, WebRequest req) {
        Map<String, String> fieldErrors = ex.getBindingResult().getAllErrors()
                .stream()
                .filter(e -> e instanceof FieldError)
                .map(e -> (FieldError) e)
                .collect(Collectors.toMap(
                        FieldError::getField,
                        fe -> fe.getDefaultMessage() != null ? fe.getDefaultMessage() : "Invalid value",
                        (existing, replacement) -> existing
                ));
        log.warn("Validation failed: {}", fieldErrors);
        Map<String, Object> body = new HashMap<>();
        body.put("status", 400);
        body.put("error", "Validation Failed");
        body.put("message", "One or more fields have validation errors");
        body.put("fieldErrors", fieldErrors);
        body.put("path", req.getDescription(false).replace("uri=", ""));
        body.put("timestamp", LocalDateTime.now().toString());
        return ResponseEntity.badRequest().body(body);
    }

    // ── 400 Missing request parameter ─────────────────────────────
    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ErrorResponse> handleMissingParam(
            MissingServletRequestParameterException ex, WebRequest req) {
        String msg = "Required parameter '" + ex.getParameterName() + "' is missing";
        log.warn("Missing param: {}", msg);
        return build(HttpStatus.BAD_REQUEST, msg, req);
    }

    // ── 400 Type mismatch (e.g. string passed where Long expected) ─
    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ErrorResponse> handleTypeMismatch(
            MethodArgumentTypeMismatchException ex, WebRequest req) {
        String msg = "Parameter '" + ex.getName() + "' has invalid value '" + ex.getValue() + "'";
        log.warn("Type mismatch: {}", msg);
        return build(HttpStatus.BAD_REQUEST, msg, req);
    }

    // ── 401 Bad credentials (wrong password) ──────────────────────
    @ExceptionHandler(BadCredentialsException.class)
    public ResponseEntity<ErrorResponse> handleBadCredentials(
            BadCredentialsException ex, WebRequest req) {
        log.warn("Login failed — bad credentials for path: {}", req.getDescription(false));
        return build(HttpStatus.UNAUTHORIZED, "Invalid email or password", req);
    }

    // ── 401 Account disabled ──────────────────────────────────────
    @ExceptionHandler(DisabledException.class)
    public ResponseEntity<ErrorResponse> handleDisabled(
            DisabledException ex, WebRequest req) {
        log.warn("Login attempt on disabled account");
        return build(HttpStatus.UNAUTHORIZED, "Account is disabled. Contact administrator.", req);
    }

    // ── 401 Account locked ────────────────────────────────────────
    @ExceptionHandler(LockedException.class)
    public ResponseEntity<ErrorResponse> handleLocked(
            LockedException ex, WebRequest req) {
        log.warn("Login attempt on locked account");
        return build(HttpStatus.UNAUTHORIZED, "Account is locked. Contact administrator.", req);
    }

    // ── 401 Custom unauthorized ───────────────────────────────────
    @ExceptionHandler(UnauthorizedException.class)
    public ResponseEntity<ErrorResponse> handleUnauthorized(
            UnauthorizedException ex, WebRequest req) {
        log.warn("Unauthorized: {}", ex.getMessage());
        return build(HttpStatus.UNAUTHORIZED, ex.getMessage(), req);
    }

    // ── 401 InternalAuthenticationServiceException ────────────────
    // Spring wraps UserNotFoundException in this — must return 401 not 500
    @ExceptionHandler(InternalAuthenticationServiceException.class)
    public ResponseEntity<ErrorResponse> handleInternalAuth(
            InternalAuthenticationServiceException ex, WebRequest req) {
        log.warn("Authentication service error: {}", ex.getMessage());
        String message = (ex.getCause() != null)
                ? ex.getCause().getMessage()
                : "Authentication failed";
        return build(HttpStatus.UNAUTHORIZED, message, req);
    }

    // ── 403 Forbidden — Spring Security 6 @PreAuthorize ──────────
    @ExceptionHandler(AuthorizationDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAuthorizationDenied(
            AuthorizationDeniedException ex, WebRequest req) {
        log.warn("Access denied [{}]: {}", req.getDescription(false), ex.getMessage());
        return build(HttpStatus.FORBIDDEN, "You do not have permission to perform this action", req);
    }

    // ── 403 Forbidden — filter-chain level ───────────────────────
    @ExceptionHandler(org.springframework.security.access.AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleAccessDenied(
            org.springframework.security.access.AccessDeniedException ex, WebRequest req) {
        log.warn("Access denied [{}]: {}", req.getDescription(false), ex.getMessage());
        return build(HttpStatus.FORBIDDEN, "You do not have permission to perform this action", req);
    }

    // ── 405 Method Not Allowed ────────────────────────────────────
    @ExceptionHandler(HttpRequestMethodNotAllowedException.class)
    public ResponseEntity<ErrorResponse> handleMethodNotAllowed(
            HttpRequestMethodNotAllowedException ex, WebRequest req) {
        String msg = "HTTP method '" + ex.getMethod() + "' is not supported for this endpoint";
        log.warn("Method not allowed: {}", msg);
        return build(HttpStatus.METHOD_NOT_ALLOWED, msg, req);
    }

    // ── 415 Unsupported Media Type ────────────────────────────────
    @ExceptionHandler(HttpMediaTypeNotSupportedException.class)
    public ResponseEntity<ErrorResponse> handleUnsupportedMedia(
            HttpMediaTypeNotSupportedException ex, WebRequest req) {
        String msg = "Content type '" + ex.getContentType() + "' is not supported. Use application/json";
        log.warn("Unsupported media type: {}", msg);
        return build(HttpStatus.UNSUPPORTED_MEDIA_TYPE, msg, req);
    }

    // ── 500 Fallback ──────────────────────────────────────────────
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleGeneral(Exception ex, WebRequest req) {
        log.error("Unhandled exception at {}: {}", req.getDescription(false), ex.getMessage(), ex);
        return build(HttpStatus.INTERNAL_SERVER_ERROR,
                "An unexpected error occurred. Please try again later.", req);
    }

    // ── Builder ───────────────────────────────────────────────────
    private ResponseEntity<ErrorResponse> build(HttpStatus status, String message, WebRequest req) {
        log.debug("Building error response: status={}, message={}", status.value(), message);
        return ResponseEntity.status(status).body(new ErrorResponse(
                status.value(),
                status.getReasonPhrase(),
                message,
                req.getDescription(false).replace("uri=", ""),
                LocalDateTime.now()
        ));
    }

    public record ErrorResponse(
            int status,
            String error,
            String message,
            String path,
            LocalDateTime timestamp) {}
}
