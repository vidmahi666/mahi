package com.educonnect.repository;

import com.educonnect.entity.Enrollment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface EnrollmentRepository extends JpaRepository<Enrollment, Long> {
    List<Enrollment> findByStudentStudentId(Long studentId);
    List<Enrollment> findByCourseCourseId(Long courseId);
    Optional<Enrollment> findByStudentStudentIdAndCourseCourseId(Long studentId, Long courseId);
    boolean existsByStudentStudentIdAndCourseCourseId(Long studentId, Long courseId);
    long countByCourseCourseId(Long courseId);
}
