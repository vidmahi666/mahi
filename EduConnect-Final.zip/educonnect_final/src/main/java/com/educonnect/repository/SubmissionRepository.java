package com.educonnect.repository;

import com.educonnect.entity.Submission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findByStudentStudentId(Long studentId);
    List<Submission> findByAssessmentAssessmentId(Long assessmentId);
    Optional<Submission> findByAssessmentAssessmentIdAndStudentStudentId(Long assessmentId, Long studentId);

    @Query("SELECT AVG(s.score) FROM Submission s WHERE s.assessment.assessmentId = :assessmentId AND s.score IS NOT NULL")
    Double findAverageScoreByAssessmentId(Long assessmentId);
}
