package com.educonnect.dto.response;

import com.educonnect.entity.Role;
import com.educonnect.entity.UserStatus;
import lombok.*;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AuthResponse {
    private Long userId;
    private String name;
    private String email;
    private Role role;
    private UserStatus status;
    private String accessToken;
    @Builder.Default
    private String tokenType = "Bearer";
    private long expiresIn;
}
