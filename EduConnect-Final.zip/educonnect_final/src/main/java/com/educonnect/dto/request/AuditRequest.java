package com.educonnect.dto.request;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AuditRequest {

    @NotNull(message = "Officer ID is required")
    @Positive(message = "Officer ID must be a positive number")
    private Long officerId;

    @NotBlank(message = "Audit scope is required")
    @Size(min = 5, max = 500, message = "Scope must be between 5 and 500 characters")
    private String scope;

    @Size(max = 5000, message = "Findings must not exceed 5000 characters")
    private String findings;
}
