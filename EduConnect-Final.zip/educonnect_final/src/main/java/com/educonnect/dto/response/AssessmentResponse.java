package com.educonnect.dto.response;

import com.educonnect.entity.Assessment;
import lombok.*;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AssessmentResponse {
    private Long assessmentId;
    private Long courseId;
    private String courseTitle;
    private String title;
    private Assessment.AssessmentType type;
    private String fileUri;
    private String instructions;
    private LocalDate dueDate;
    private Integer maxScore;
    private Integer passingScore;
    private Assessment.AssessmentStatus status;
    private LocalDateTime createdAt;
}
