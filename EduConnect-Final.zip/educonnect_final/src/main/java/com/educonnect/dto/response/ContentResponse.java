package com.educonnect.dto.response;

import com.educonnect.entity.Content;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class ContentResponse {
    private Long contentId;
    private Long courseId;
    private String courseTitle;
    private String title;
    private Content.ContentType type;
    private String fileUri;
    private LocalDateTime uploadedDate;
    private Content.ContentStatus status;
}
