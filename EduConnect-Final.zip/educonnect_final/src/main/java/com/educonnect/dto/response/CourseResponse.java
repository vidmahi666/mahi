package com.educonnect.dto.response;

import com.educonnect.entity.Course;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class CourseResponse {
    private Long courseId;
    private String title;
    private String description;
    private Long teacherId;
    private String teacherName;
    private LocalDate startDate;
    private LocalDate endDate;
    private Course.CourseStatus status;
    private LocalDateTime createdAt;
}
