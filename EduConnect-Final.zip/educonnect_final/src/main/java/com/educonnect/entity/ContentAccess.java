package com.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "content_access")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ContentAccess {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long accessId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "student_id", nullable = false) private Student student;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "content_id", nullable = false) private Content content;
    @CreationTimestamp private LocalDateTime accessDate;
    @Enumerated(EnumType.STRING) @Builder.Default private AccessStatus status = AccessStatus.ACCESSED;
    public enum AccessStatus { ACCESSED, COMPLETED, IN_PROGRESS }
}
