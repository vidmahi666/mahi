package com.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDate;
import java.time.LocalDateTime;

@Entity @Table(name = "assessments")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Assessment {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long assessmentId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "course_id", nullable = false) private Course course;
    @Column(nullable = false) private String title;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private AssessmentType type;
    private String fileUri;
    @Column(columnDefinition = "TEXT") private String instructions;
    private LocalDate dueDate;
    private Integer maxScore;
    private Integer passingScore;
    @Enumerated(EnumType.STRING) @Builder.Default private AssessmentStatus status = AssessmentStatus.DRAFT;
    @CreationTimestamp private LocalDateTime createdAt;
    @UpdateTimestamp  private LocalDateTime updatedAt;
    public enum AssessmentType   { ASSIGNMENT, EXAM, QUIZ, PROJECT }
    public enum AssessmentStatus { DRAFT, ACTIVE, CLOSED, ARCHIVED }
}
