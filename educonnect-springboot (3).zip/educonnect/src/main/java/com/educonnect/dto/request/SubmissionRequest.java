package com.educonnect.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SubmissionRequest {
    @NotNull private Long assessmentId;
    @NotNull private Long studentId;
    private String fileUri;
}
