package com.educonnect.dto.request;

import com.educonnect.entity.Assessment;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter @Setter
public class AssessmentRequest {
    @NotNull   private Long courseId;
    @NotBlank  private String title;
    @NotNull   private Assessment.AssessmentType type;
    private LocalDate dueDate;
    private Integer maxScore;
}
