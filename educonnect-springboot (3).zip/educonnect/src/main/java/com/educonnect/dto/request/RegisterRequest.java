package com.educonnect.dto.request;

import com.educonnect.entity.Role;
import jakarta.validation.constraints.Email;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class RegisterRequest {
    @NotBlank          private String name;
    @Email @NotBlank   private String email;
    @NotBlank          private String password;
    private String phone;
    @NotNull           private Role role;
}
