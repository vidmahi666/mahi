package com.educonnect.dto.response;

import com.educonnect.entity.Assessment;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AssessmentResponse {
    private Long assessmentId;
    private Long courseId;
    private String courseTitle;
    private String title;
    private Assessment.AssessmentType type;
    private LocalDate dueDate;
    private Integer maxScore;
    private Assessment.AssessmentStatus status;
}
