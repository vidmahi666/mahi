package com.educonnect.dto.request;

import com.educonnect.entity.Notification;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class NotificationRequest {
    @NotNull   private Long userId;
    private Long entityId;
    @NotBlank  private String message;
    @NotNull   private Notification.NotificationCategory category;
}
