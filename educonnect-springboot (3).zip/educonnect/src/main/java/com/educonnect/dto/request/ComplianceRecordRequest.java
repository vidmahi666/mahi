package com.educonnect.dto.request;

import com.educonnect.entity.ComplianceRecord;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ComplianceRecordRequest {
    @NotNull private Long entityId;
    @NotNull private ComplianceRecord.ComplianceType type;
    private ComplianceRecord.ComplianceResult result;
    private String notes;
}
