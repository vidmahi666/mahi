package com.educonnect.dto.request;

import com.educonnect.entity.Content;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ContentRequest {
    @NotNull   private Long courseId;
    @NotBlank  private String title;
    @NotNull   private Content.ContentType type;
    private String fileUri;
}
