package com.educonnect.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDate;

@Getter @Setter
public class CourseRequest {
    @NotBlank  private String title;
    private String description;
    @NotNull   private Long teacherId;
    private LocalDate startDate;
    private LocalDate endDate;
}
