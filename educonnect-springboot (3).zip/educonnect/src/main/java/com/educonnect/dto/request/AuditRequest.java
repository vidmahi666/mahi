package com.educonnect.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class AuditRequest {
    @NotNull   private Long officerId;
    @NotBlank  private String scope;
    private String findings;
}
