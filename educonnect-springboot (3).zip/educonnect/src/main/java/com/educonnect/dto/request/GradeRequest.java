package com.educonnect.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class GradeRequest {
    @NotNull private Integer score;
    private String feedback;
}
