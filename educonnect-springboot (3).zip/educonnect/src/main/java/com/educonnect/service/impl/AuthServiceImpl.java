package com.educonnect.service.impl;

import com.educonnect.dto.request.LoginRequest;
import com.educonnect.dto.request.RegisterRequest;
import com.educonnect.dto.response.AuthResponse;
import com.educonnect.entity.Student;
import com.educonnect.entity.User;
import com.educonnect.entity.UserStatus;
import com.educonnect.exception.BadRequestException;
import com.educonnect.repository.StudentRepository;
import com.educonnect.repository.UserRepository;
import com.educonnect.security.JwtUtils;
import com.educonnect.service.AuthService;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository        userRepository;
    private final StudentRepository     studentRepository;
    private final PasswordEncoder       passwordEncoder;
    private final JwtUtils              jwtUtils;
    private final AuthenticationManager authenticationManager;
    private final UserDetailsService    userDetailsService;

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException("Email already registered: " + request.getEmail());
        }

        User user = User.builder()
                .name(request.getName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .phone(request.getPhone())
                .role(request.getRole())
                .status(UserStatus.ACTIVE)
                .build();

        user = userRepository.save(user);

        // Auto-create Student profile for STUDENT role
        if (user.getRole().name().equals("STUDENT")) {
            Student student = Student.builder()
                    .user(user)
                    .name(user.getName())
                    .contactInfo(user.getPhone())
                    .build();
            studentRepository.save(student);
        }

        UserDetails ud = userDetailsService.loadUserByUsername(user.getEmail());
        return buildResponse(user,
                jwtUtils.generateToken(ud),
                jwtUtils.generateRefreshToken(ud));
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        authenticationManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(), request.getPassword()));

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new BadRequestException("User not found"));

        UserDetails ud = userDetailsService.loadUserByUsername(user.getEmail());
        return buildResponse(user,
                jwtUtils.generateToken(ud),
                jwtUtils.generateRefreshToken(ud));
    }

    @Override
    public AuthResponse refreshToken(String refreshToken) {
        String email = jwtUtils.extractUsername(refreshToken);
        UserDetails ud = userDetailsService.loadUserByUsername(email);

        if (!jwtUtils.isTokenValid(refreshToken, ud)) {
            throw new BadRequestException("Invalid or expired refresh token");
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new BadRequestException("User not found"));

        return buildResponse(user, jwtUtils.generateToken(ud), refreshToken);
    }

    private AuthResponse buildResponse(User user, String access, String refresh) {
        return AuthResponse.builder()
                .userId(user.getUserId())
                .name(user.getName())
                .email(user.getEmail())
                .role(user.getRole())
                .status(user.getStatus())
                .accessToken(access)
                .refreshToken(refresh)
                .build();
    }
}
