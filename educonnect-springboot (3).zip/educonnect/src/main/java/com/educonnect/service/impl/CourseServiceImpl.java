package com.educonnect.service.impl;

import com.educonnect.dto.request.CourseRequest;
import com.educonnect.dto.response.CourseResponse;
import com.educonnect.entity.Course;
import com.educonnect.entity.User;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.CourseRepository;
import com.educonnect.repository.UserRepository;
import com.educonnect.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final UserRepository   userRepository;

    @Override
    @Transactional
    public CourseResponse createCourse(CourseRequest request) {
        User teacher = userRepository.findById(request.getTeacherId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Teacher not found: " + request.getTeacherId()));
        Course course = Course.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .teacher(teacher)
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .build();
        return mapToResponse(courseRepository.save(course));
    }

    @Override
    public CourseResponse getCourseById(Long id) {
        return mapToResponse(findOrThrow(id));
    }

    @Override
    public List<CourseResponse> getAllCourses() {
        return courseRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<CourseResponse> getCoursesByTeacher(Long teacherId) {
        return courseRepository.findByTeacherUserId(teacherId)
                .stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<CourseResponse> searchCourses(String keyword) {
        return courseRepository.searchByTitle(keyword)
                .stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public CourseResponse updateCourse(Long id, CourseRequest request) {
        Course course = findOrThrow(id);
        User teacher = userRepository.findById(request.getTeacherId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Teacher not found: " + request.getTeacherId()));
        course.setTitle(request.getTitle());
        course.setDescription(request.getDescription());
        course.setTeacher(teacher);
        course.setStartDate(request.getStartDate());
        course.setEndDate(request.getEndDate());
        return mapToResponse(courseRepository.save(course));
    }

    @Override
    @Transactional
    public void deleteCourse(Long id) {
        Course course = findOrThrow(id);
        course.setStatus(Course.CourseStatus.ARCHIVED);
        courseRepository.save(course);
    }

    private Course findOrThrow(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found: " + id));
    }

    private CourseResponse mapToResponse(Course c) {
        return CourseResponse.builder()
                .courseId(c.getCourseId())
                .title(c.getTitle())
                .description(c.getDescription())
                .teacherId(c.getTeacher().getUserId())
                .teacherName(c.getTeacher().getName())
                .startDate(c.getStartDate())
                .endDate(c.getEndDate())
                .status(c.getStatus())
                .createdAt(c.getCreatedAt())
                .build();
    }
}
