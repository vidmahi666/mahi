package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.AuditLogRequest;
import com.cognizant.educonnect.dto.response.AuditLogResponse;
import com.cognizant.educonnect.entity.AuditLog;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.AuditLogRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository     userRepository;

    // ── REST-invoked create ───────────────────────────────────────
    @Override
    @Transactional
    public AuditLogResponse create(AuditLogRequest request) {
        log.info("Creating audit log: userId={}, action={}, resource={}",
                request.getUserId(), request.getAction(), request.getResource());

        User user = userRepository.findById(request.getUserId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found: " + request.getUserId()));

        AuditLog log_ = AuditLog.builder()
                .user(user)
                .action(request.getAction())
                .resource(request.getResource())
                .build();

        return toResponse(auditLogRepository.save(log_));
    }

    // ── Queries ───────────────────────────────────────────────────
    @Override
    @Transactional(readOnly = true)
    public List<AuditLogResponse> getAll() {
        return auditLogRepository.findAllByOrderByTimestampDesc()
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogResponse> getByUser(Long userId) {
        if (!userRepository.existsById(userId)) {
            throw new ResourceNotFoundException("User not found: " + userId);
        }
        return auditLogRepository.findByUserUserIdOrderByTimestampDesc(userId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogResponse> getByDateRange(LocalDateTime from, LocalDateTime to) {
        return auditLogRepository.findByTimestampBetweenOrderByTimestampDesc(from, to)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public AuditLogResponse getById(Long id) {
        return toResponse(auditLogRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Audit log not found: " + id)));
    }

    // ── Internal async log (called from other services) ───────────
    @Override
    @Async
    @Transactional
    public void logAsync(Long userId, String action, String resource) {
        try {
            User user = userRepository.findById(userId).orElse(null);
            AuditLog entry = AuditLog.builder()
                    .user(user)
                    .action(action)
                    .resource(resource)
                    .build();
            auditLogRepository.save(entry);
            log.debug("Audit logged: userId={}, action={}", userId, action);
        } catch (Exception e) {
            log.error("Failed to save async audit log for userId={}: {}", userId, e.getMessage());
        }
    }

    // ── Mapper ────────────────────────────────────────────────────
    private AuditLogResponse toResponse(AuditLog a) {
        return AuditLogResponse.builder()
                .auditLogId(a.getAuditLogId())
                .userId(a.getUser() != null ? a.getUser().getUserId() : null)
                .userName(a.getUser() != null ? a.getUser().getName() : "SYSTEM")
                .userEmail(a.getUser() != null ? a.getUser().getEmail() : null)
                .action(a.getAction())
                .resource(a.getResource())
                .timestamp(a.getTimestamp())
                .build();
    }
}
