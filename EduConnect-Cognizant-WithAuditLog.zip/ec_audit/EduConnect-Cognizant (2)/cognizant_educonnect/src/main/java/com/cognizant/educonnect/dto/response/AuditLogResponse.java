package com.cognizant.educonnect.dto.response;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class AuditLogResponse {
    private Long auditLogId;
    private Long userId;
    private String userName;
    private String userEmail;
    private String action;
    private String resource;
    private LocalDateTime timestamp;
}
