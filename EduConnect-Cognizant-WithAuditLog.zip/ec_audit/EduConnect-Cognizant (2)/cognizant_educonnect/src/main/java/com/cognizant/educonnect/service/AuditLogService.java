package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.AuditLogRequest;
import com.cognizant.educonnect.dto.response.AuditLogResponse;

import java.time.LocalDateTime;
import java.util.List;

public interface AuditLogService {

    /** Manually record an audit event via REST API */
    AuditLogResponse create(AuditLogRequest request);

    /** Get all audit logs (newest first) */
    List<AuditLogResponse> getAll();

    /** Get audit logs for a specific user */
    List<AuditLogResponse> getByUser(Long userId);

    /** Get audit logs within a date-time range */
    List<AuditLogResponse> getByDateRange(LocalDateTime from, LocalDateTime to);

    /** Get audit log by ID */
    AuditLogResponse getById(Long id);

    /** Async background log — called internally from services */
    void logAsync(Long userId, String action, String resource);
}
