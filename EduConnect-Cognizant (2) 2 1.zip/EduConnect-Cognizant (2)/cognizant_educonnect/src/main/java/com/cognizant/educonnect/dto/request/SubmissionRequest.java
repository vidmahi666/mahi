package com.cognizant.educonnect.dto.request;

import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class SubmissionRequest {

    @NotNull(message = "Assessment ID is required")
    @Positive(message = "Assessment ID must be a positive number")
    private Long assessmentId;

    @NotNull(message = "Student ID is required")
    @Positive(message = "Student ID must be a positive number")
    private Long studentId;

    @NotBlank(message = "File URI is required for submission")
    @Pattern(
        regexp = "^(https?://|s3://|/).+",
        message = "File URI must be a valid http/https URL, s3:// URI, or absolute path"
    )
    private String fileUri;

    @Size(max = 500, message = "Remarks must not exceed 500 characters")
    private String remarks;
}
