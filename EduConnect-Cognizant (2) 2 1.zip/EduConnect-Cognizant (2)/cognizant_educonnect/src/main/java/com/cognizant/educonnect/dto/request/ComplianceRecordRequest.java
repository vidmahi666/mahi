package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.ComplianceRecord;
import jakarta.validation.constraints.*;
import lombok.Getter;
import lombok.Setter;

@Getter @Setter
public class ComplianceRecordRequest {

    @NotNull(message = "Entity ID is required")
    @Positive(message = "Entity ID must be a positive number")
    private Long entityId;

    @NotNull(message = "Compliance type is required")
    private ComplianceRecord.ComplianceType type;

    private ComplianceRecord.ComplianceResult result;

    @Size(max = 2000, message = "Notes must not exceed 2000 characters")
    private String notes;
}
