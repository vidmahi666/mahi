package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Submission;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDateTime;

@Getter @Setter @Builder @NoArgsConstructor @AllArgsConstructor
public class SubmissionResponse {
    private Long submissionId;
    private Long assessmentId;
    private String assessmentTitle;
    private Long studentId;
    private String studentName;
    private String fileUri;
    private LocalDateTime submissionDate;
    private Integer score;
    private String feedback;
    private Submission.SubmissionStatus status;
}
