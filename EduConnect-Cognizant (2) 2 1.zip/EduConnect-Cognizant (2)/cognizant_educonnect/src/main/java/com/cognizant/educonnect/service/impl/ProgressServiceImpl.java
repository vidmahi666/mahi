package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.response.ProgressResponse;
import com.cognizant.educonnect.entity.Course;
import com.cognizant.educonnect.entity.Progress;
import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.CourseRepository;
import com.cognizant.educonnect.repository.ProgressRepository;
import com.cognizant.educonnect.repository.StudentRepository;
import com.cognizant.educonnect.service.ProgressService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ProgressServiceImpl implements ProgressService {

    private final ProgressRepository progressRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    @Override
    public ProgressResponse getProgressByStudentAndCourse(Long studentId, Long courseId) {
        Progress p = progressRepository.findByStudentStudentIdAndCourseCourseId(studentId, courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Progress not found"));
        return mapToResponse(p);
    }

    @Override
    public List<ProgressResponse> getProgressByStudent(Long studentId) {
        return progressRepository.findByStudentStudentId(studentId).stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public ProgressResponse updateProgress(Long studentId, Long courseId, Double completionPercentage) {
        Progress progress = progressRepository.findByStudentStudentIdAndCourseCourseId(studentId, courseId)
                .orElseGet(() -> {
                    Student student = studentRepository.findById(studentId)
                            .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
                    Course course = courseRepository.findById(courseId)
                            .orElseThrow(() -> new ResourceNotFoundException("Course not found"));
                    return Progress.builder().student(student).course(course).build();
                });
        progress.setCompletionPercentage(completionPercentage);
        if (completionPercentage >= 100.0) progress.setStatus(Progress.ProgressStatus.COMPLETED);
        return mapToResponse(progressRepository.save(progress));
    }

    private ProgressResponse mapToResponse(Progress p) {
        return ProgressResponse.builder()
                .progressId(p.getProgressId()).studentId(p.getStudent().getStudentId())
                .studentName(p.getStudent().getName()).courseId(p.getCourse().getCourseId())
                .courseTitle(p.getCourse().getTitle()).completionPercentage(p.getCompletionPercentage())
                .metricsJson(p.getMetricsJson()).status(p.getStatus()).updatedAt(p.getUpdatedAt()).build();
    }
}
