package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Content;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContentRepository extends JpaRepository<Content, Long> {
    List<Content> findByCourseCourseId(Long courseId);
    List<Content> findByCourseCourseIdAndStatus(Long courseId, Content.ContentStatus status);
    List<Content> findByType(Content.ContentType type);
}
