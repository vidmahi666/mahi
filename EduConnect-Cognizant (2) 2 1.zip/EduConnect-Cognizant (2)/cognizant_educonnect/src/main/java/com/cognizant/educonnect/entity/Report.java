package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long reportId;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ReportScope scope;
    @Column(columnDefinition = "TEXT") private String metrics;
    @CreationTimestamp private LocalDateTime generatedDate;
    private String generatedBy;
    public enum ReportScope { COURSE, ASSESSMENT, PROGRAM, COMPLIANCE, STUDENT }
}
