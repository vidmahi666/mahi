package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.AssessmentRequest;
import com.cognizant.educonnect.dto.request.GradeRequest;
import com.cognizant.educonnect.dto.request.SubmissionRequest;
import com.cognizant.educonnect.dto.response.AssessmentResponse;
import com.cognizant.educonnect.dto.response.SubmissionResponse;
import com.cognizant.educonnect.entity.*;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.*;
import com.cognizant.educonnect.service.AssessmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class AssessmentServiceImpl implements AssessmentService {

    private final AssessmentRepository assessmentRepository;
    private final SubmissionRepository submissionRepository;
    private final CourseRepository     courseRepository;
    private final StudentRepository    studentRepository;

    @Override
    @Transactional
    public AssessmentResponse createAssessment(AssessmentRequest request) {
        log.info("Creating assessment '{}' for courseId={}", request.getTitle(), request.getCourseId());
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found: " + request.getCourseId()));

        if (request.getPassingScore() != null && request.getMaxScore() != null
                && request.getPassingScore() > request.getMaxScore()) {
            throw new BadRequestException("Passing score cannot exceed max score");
        }

        Assessment a = Assessment.builder()
                .course(course)
                .title(request.getTitle())
                .type(request.getType())
                .fileUri(request.getFileUri())
                .instructions(request.getInstructions())
                .dueDate(request.getDueDate())
                .maxScore(request.getMaxScore())
                .passingScore(request.getPassingScore())
                .build();

        Assessment saved = assessmentRepository.save(a);
        log.info("Assessment created with ID={}", saved.getAssessmentId());
        return mapToAssessmentResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public AssessmentResponse getAssessmentById(Long id) {
        log.debug("Fetching assessment id={}", id);
        return mapToAssessmentResponse(findAssessmentOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AssessmentResponse> getAssessmentsByCourse(Long courseId) {
        log.debug("Fetching assessments for courseId={}", courseId);
        return assessmentRepository.findByCourseCourseId(courseId)
                .stream().map(this::mapToAssessmentResponse).toList();
    }

    @Override
    @Transactional
    public AssessmentResponse updateAssessment(Long id, AssessmentRequest request) {
        log.info("Updating assessment id={}", id);
        Assessment a = findAssessmentOrThrow(id);

        if (request.getPassingScore() != null && request.getMaxScore() != null
                && request.getPassingScore() > request.getMaxScore()) {
            throw new BadRequestException("Passing score cannot exceed max score");
        }

        a.setTitle(request.getTitle());
        a.setType(request.getType());
        a.setFileUri(request.getFileUri());
        a.setInstructions(request.getInstructions());
        a.setDueDate(request.getDueDate());
        a.setMaxScore(request.getMaxScore());
        a.setPassingScore(request.getPassingScore());
        return mapToAssessmentResponse(assessmentRepository.save(a));
    }

    @Override
    @Transactional
    public void deleteAssessment(Long id) {
        log.info("Archiving assessment id={}", id);
        Assessment a = findAssessmentOrThrow(id);
        a.setStatus(Assessment.AssessmentStatus.ARCHIVED);
        assessmentRepository.save(a);
    }

    @Override
    @Transactional
    public SubmissionResponse submitAssessment(SubmissionRequest request) {
        log.info("Student {} submitting to assessment {}", request.getStudentId(), request.getAssessmentId());
        Assessment assessment = findAssessmentOrThrow(request.getAssessmentId());

        if (assessment.getStatus() != Assessment.AssessmentStatus.ACTIVE) {
            throw new BadRequestException("Assessment is not open for submissions. Current status: " + assessment.getStatus());
        }

        if (submissionRepository.findByAssessmentAssessmentIdAndStudentStudentId(
                request.getAssessmentId(), request.getStudentId()).isPresent()) {
            throw new BadRequestException("Student has already submitted this assessment");
        }

        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + request.getStudentId()));

        Submission s = Submission.builder()
                .assessment(assessment)
                .student(student)
                .fileUri(request.getFileUri())
                .build();

        Submission saved = submissionRepository.save(s);
        log.info("Submission created with ID={}", saved.getSubmissionId());
        return mapToSubmissionResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<SubmissionResponse> getSubmissionsByAssessment(Long assessmentId) {
        return submissionRepository.findByAssessmentAssessmentId(assessmentId)
                .stream().map(this::mapToSubmissionResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<SubmissionResponse> getSubmissionsByStudent(Long studentId) {
        return submissionRepository.findByStudentStudentId(studentId)
                .stream().map(this::mapToSubmissionResponse).toList();
    }

    @Override
    @Transactional
    public SubmissionResponse gradeSubmission(Long submissionId, GradeRequest request) {
        log.info("Grading submissionId={} with score={}", submissionId, request.getScore());
        Submission s = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException("Submission not found: " + submissionId));

        Integer maxScore = s.getAssessment().getMaxScore();
        if (maxScore != null && request.getScore() > maxScore) {
            throw new BadRequestException("Score " + request.getScore() + " exceeds max score " + maxScore);
        }

        s.setScore(request.getScore());
        s.setFeedback(request.getFeedback());
        s.setStatus(Submission.SubmissionStatus.GRADED);
        return mapToSubmissionResponse(submissionRepository.save(s));
    }

    // ── Helpers ───────────────────────────────────────────────────
    private Assessment findAssessmentOrThrow(Long id) {
        return assessmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Assessment not found: " + id));
    }

    private AssessmentResponse mapToAssessmentResponse(Assessment a) {
        return AssessmentResponse.builder()
                .assessmentId(a.getAssessmentId())
                .courseId(a.getCourse().getCourseId())
                .courseTitle(a.getCourse().getTitle())
                .title(a.getTitle())
                .type(a.getType())
                .fileUri(a.getFileUri())
                .instructions(a.getInstructions())
                .dueDate(a.getDueDate())
                .maxScore(a.getMaxScore())
                .passingScore(a.getPassingScore())
                .status(a.getStatus())
                .createdAt(a.getCreatedAt())
                .build();
    }

    private SubmissionResponse mapToSubmissionResponse(Submission s) {
        return SubmissionResponse.builder()
                .submissionId(s.getSubmissionId())
                .assessmentId(s.getAssessment().getAssessmentId())
                .assessmentTitle(s.getAssessment().getTitle())
                .studentId(s.getStudent().getStudentId())
                .studentName(s.getStudent().getName())
                .fileUri(s.getFileUri())
                .submissionDate(s.getSubmissionDate())
                .score(s.getScore())
                .feedback(s.getFeedback())
                .status(s.getStatus())
                .build();
    }
}
