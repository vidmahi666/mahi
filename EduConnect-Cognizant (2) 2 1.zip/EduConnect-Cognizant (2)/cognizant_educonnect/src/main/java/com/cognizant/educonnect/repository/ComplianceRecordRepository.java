package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.ComplianceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplianceRecordRepository extends JpaRepository<ComplianceRecord, Long> {
    List<ComplianceRecord> findByEntityId(Long entityId);
    List<ComplianceRecord> findByType(ComplianceRecord.ComplianceType type);
    List<ComplianceRecord> findByResult(ComplianceRecord.ComplianceResult result);
}
