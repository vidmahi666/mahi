package com.cognizant.educonnect.entity;
public enum UserStatus { ACTIVE, INACTIVE, SUSPENDED }
