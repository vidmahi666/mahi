package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.response.ProgressResponse;
import java.util.List;

public interface ProgressService {
    ProgressResponse getProgressByStudentAndCourse(Long studentId, Long courseId);
    List<ProgressResponse> getProgressByStudent(Long studentId);
    ProgressResponse updateProgress(Long studentId, Long courseId, Double completionPercentage);
}
