package com.cognizant.educonnect.entity;
public enum Role { STUDENT, TEACHER, ADMIN, PROGRAM_MANAGER, COMPLIANCE_OFFICER, GOVERNMENT_AUDITOR }
