package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Audit;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AuditRepository extends JpaRepository<Audit, Long> {
    List<Audit> findByOfficerUserId(Long officerId);
    List<Audit> findByStatus(Audit.AuditStatus status);
}
