package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.ProgressResponse;
import com.cognizant.educonnect.service.ProgressService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/progress")
@RequiredArgsConstructor
@Tag(name = "Progress", description = "Student progress tracking APIs")
public class ProgressController {

    private final ProgressService progressService;

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get all progress for a student")
    public ResponseEntity<ApiResponse<List<ProgressResponse>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success(progressService.getProgressByStudent(studentId), "Progress retrieved"));
    }

    @GetMapping("/student/{studentId}/course/{courseId}")
    @Operation(summary = "Get progress by student and course")
    public ResponseEntity<ApiResponse<ProgressResponse>> getProgress(@PathVariable Long studentId, @PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(progressService.getProgressByStudentAndCourse(studentId, courseId), "Progress retrieved"));
    }

    @PutMapping("/student/{studentId}/course/{courseId}")
    @Operation(summary = "Update progress")
    public ResponseEntity<ApiResponse<ProgressResponse>> update(@PathVariable Long studentId, @PathVariable Long courseId, @RequestParam Double completionPercentage) {
        return ResponseEntity.ok(ApiResponse.success(progressService.updateProgress(studentId, courseId, completionPercentage), "Progress updated"));
    }
}
