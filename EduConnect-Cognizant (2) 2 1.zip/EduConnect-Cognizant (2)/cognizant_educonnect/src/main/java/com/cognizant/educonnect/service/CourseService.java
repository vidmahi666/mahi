package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.CourseRequest;
import com.cognizant.educonnect.dto.response.CourseResponse;
import java.util.List;

public interface CourseService {
    CourseResponse createCourse(CourseRequest request);
    CourseResponse getCourseById(Long id);
    List<CourseResponse> getAllCourses();
    List<CourseResponse> getCoursesByTeacher(Long teacherId);
    CourseResponse updateCourse(Long id, CourseRequest request);
    void deleteCourse(Long id);
    List<CourseResponse> searchCourses(String keyword);
}
