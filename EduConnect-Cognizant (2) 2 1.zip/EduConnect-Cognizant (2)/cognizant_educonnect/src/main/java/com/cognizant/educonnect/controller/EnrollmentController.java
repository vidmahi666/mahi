package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.EnrollmentRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.EnrollmentResponse;
import com.cognizant.educonnect.service.EnrollmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/enrollments")
@RequiredArgsConstructor
@Tag(name = "Enrollments", description = "Course enrollment APIs")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    @PostMapping
    @Operation(summary = "Enroll student in course")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> enroll(@Valid @RequestBody EnrollmentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(enrollmentService.enroll(request), "Enrolled successfully"));
    }

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get enrollments by student")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success(enrollmentService.getEnrollmentsByStudent(studentId), "Enrollments retrieved"));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get enrollments by course")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(enrollmentService.getEnrollmentsByCourse(courseId), "Enrollments retrieved"));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update enrollment status")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> updateStatus(@PathVariable Long id, @RequestParam String status) {
        return ResponseEntity.ok(ApiResponse.success(enrollmentService.updateStatus(id, status), "Status updated"));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Unenroll student")
    public ResponseEntity<ApiResponse<Void>> unenroll(@PathVariable Long id) {
        enrollmentService.unenroll(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Unenrolled successfully"));
    }
}
