package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.entity.StudentDocument;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.StudentDocumentRepository;
import com.cognizant.educonnect.repository.StudentRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/student-documents")
@RequiredArgsConstructor
@Tag(name = "Student Documents", description = "Student document verification APIs")
public class StudentDocumentController {

    private final StudentDocumentRepository studentDocumentRepository;
    private final StudentRepository studentRepository;

    @GetMapping("/student/{studentId}")
    @Operation(summary = "Get all documents for a student")
    public ResponseEntity<ApiResponse<List<StudentDocument>>> getByStudent(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success(
                studentDocumentRepository.findByStudentStudentId(studentId), "Documents retrieved"));
    }

    @PostMapping("/student/{studentId}")
    @Operation(summary = "Upload a document for a student")
    public ResponseEntity<ApiResponse<StudentDocument>> upload(@PathVariable Long studentId,
                                                                @RequestParam String docType,
                                                                @RequestParam String fileUri) {
        var student = studentRepository.findById(studentId)
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
        StudentDocument doc = StudentDocument.builder()
                .student(student)
                .docType(StudentDocument.DocType.valueOf(docType.toUpperCase()))
                .fileUri(fileUri)
                .build();
        return ResponseEntity.ok(ApiResponse.success(studentDocumentRepository.save(doc), "Document uploaded"));
    }

    @PatchMapping("/{docId}/verify")
    @PreAuthorize("hasAnyRole('ADMIN','COMPLIANCE_OFFICER')")
    @Operation(summary = "Verify or reject a document")
    public ResponseEntity<ApiResponse<StudentDocument>> verify(@PathVariable Long docId,
                                                                @RequestParam String status) {
        StudentDocument doc = studentDocumentRepository.findById(docId)
                .orElseThrow(() -> new ResourceNotFoundException("Document not found: " + docId));
        doc.setVerificationStatus(StudentDocument.VerificationStatus.valueOf(status.toUpperCase()));
        return ResponseEntity.ok(ApiResponse.success(studentDocumentRepository.save(doc), "Document status updated"));
    }
}
