package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Progress;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface ProgressRepository extends JpaRepository<Progress, Long> {
    List<Progress> findByStudentStudentId(Long studentId);
    Optional<Progress> findByStudentStudentIdAndCourseCourseId(Long studentId, Long courseId);
    List<Progress> findByCourseCourseId(Long courseId);
}
