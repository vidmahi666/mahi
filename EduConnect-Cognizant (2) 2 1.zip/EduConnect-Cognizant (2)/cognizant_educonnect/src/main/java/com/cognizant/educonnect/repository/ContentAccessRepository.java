package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.ContentAccess;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContentAccessRepository extends JpaRepository<ContentAccess, Long> {
    List<ContentAccess> findByStudentStudentId(Long studentId);
    List<ContentAccess> findByContentContentId(Long contentId);
    boolean existsByStudentStudentIdAndContentContentId(Long studentId, Long contentId);
}
