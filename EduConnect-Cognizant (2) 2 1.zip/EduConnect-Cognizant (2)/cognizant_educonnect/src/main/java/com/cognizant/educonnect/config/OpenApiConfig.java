package com.cognizant.educonnect.config;

import io.swagger.v3.oas.models.Components;
import io.swagger.v3.oas.models.OpenAPI;
import io.swagger.v3.oas.models.info.Contact;
import io.swagger.v3.oas.models.info.Info;
import io.swagger.v3.oas.models.info.License;
import io.swagger.v3.oas.models.security.SecurityRequirement;
import io.swagger.v3.oas.models.security.SecurityScheme;
import io.swagger.v3.oas.models.servers.Server;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import java.util.List;

@Configuration
public class OpenApiConfig {

    @Bean
    public OpenAPI customOpenAPI() {
        final String securitySchemeName = "Bearer Authentication";

        return new OpenAPI()
            .info(new Info()
                .title("EduConnect API")
                .version("1.0.0")
                .description("""
                    ## EduConnect - Digital Education & E-Learning Governance System
                    
                    ### Authentication
                    1. **Register** a user via `POST /api/auth/register`
                    2. **Login** via `POST /api/auth/login` to get a Bearer token
                    3. Click **Authorize** button above and enter: `Bearer <your_token>`
                    4. All subsequent requests will include the token automatically
                    
                    ### Pre-seeded Users (password: password123)
                    | Email | Role |
                    |-------|------|
                    | admin@educonnect.com | ADMIN |
                    | sarah.johnson@educonnect.com | TEACHER |
                    | michael.chen@educonnect.com | TEACHER |
                    | manager@educonnect.com | PROGRAM_MANAGER |
                    | compliance@educonnect.com | COMPLIANCE_OFFICER |
                    | auditor@educonnect.com | GOVERNMENT_AUDITOR |
                    
                    ### Available Roles
                    `STUDENT` `TEACHER` `ADMIN` `PROGRAM_MANAGER` `COMPLIANCE_OFFICER` `GOVERNMENT_AUDITOR`
                    """)
                .contact(new Contact()
                    .name("EduConnect Team")
                    .email("support@educonnect.com"))
                .license(new License().name("MIT")))
            .servers(List.of(
                new Server().url("http://localhost:8080").description("Local Development Server")))
            .addSecurityItem(new SecurityRequirement().addList(securitySchemeName))
            .components(new Components()
                .addSecuritySchemes(securitySchemeName, new SecurityScheme()
                    .name(securitySchemeName)
                    .type(SecurityScheme.Type.HTTP)
                    .scheme("bearer")
                    .bearerFormat("JWT")
                    .description("Enter your JWT token (without 'Bearer ' prefix)")));
    }
}
