package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "contents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Content {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long contentId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "course_id", nullable = false) private Course course;
    @Column(nullable = false) private String title;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private ContentType type;
    @Column(nullable = false) private String fileUri;
    private String description;
    private Integer sortOrder;
    @CreationTimestamp private LocalDateTime uploadedDate;
    @Enumerated(EnumType.STRING) @Builder.Default private ContentStatus status = ContentStatus.ACTIVE;
    public enum ContentType   { VIDEO, PDF, QUIZ, DOCUMENT, PRESENTATION }
    public enum ContentStatus { ACTIVE, INACTIVE, ARCHIVED }
}
