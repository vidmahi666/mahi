package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.EnrollmentRequest;
import com.cognizant.educonnect.dto.response.EnrollmentResponse;
import com.cognizant.educonnect.entity.Course;
import com.cognizant.educonnect.entity.Enrollment;
import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.CourseRepository;
import com.cognizant.educonnect.repository.EnrollmentRepository;
import com.cognizant.educonnect.repository.StudentRepository;
import com.cognizant.educonnect.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Slf4j
@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository    studentRepository;
    private final CourseRepository     courseRepository;

    @Override
    @Transactional
    public EnrollmentResponse enroll(EnrollmentRequest request) {
        log.info("Enrolling studentId={} into courseId={}", request.getStudentId(), request.getCourseId());
        if (enrollmentRepository.existsByStudentStudentIdAndCourseCourseId(request.getStudentId(), request.getCourseId())) {
            throw new BadRequestException("Student is already enrolled in this course");
        }
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found: " + request.getStudentId()));
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found: " + request.getCourseId()));

        Enrollment e = Enrollment.builder().student(student).course(course).build();
        Enrollment saved = enrollmentRepository.save(e);
        log.info("Enrollment created ID={}", saved.getEnrollmentId());
        return mapToResponse(saved);
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getEnrollmentsByStudent(Long studentId) {
        return enrollmentRepository.findByStudentStudentId(studentId).stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getEnrollmentsByCourse(Long courseId) {
        return enrollmentRepository.findByCourseCourseId(courseId).stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public EnrollmentResponse updateStatus(Long id, String status) {
        log.info("Updating enrollment id={} to status={}", id, status);
        Enrollment enrollment = findOrThrow(id);
        enrollment.setStatus(Enrollment.EnrollmentStatus.valueOf(status.toUpperCase()));
        return mapToResponse(enrollmentRepository.save(enrollment));
    }

    @Override
    @Transactional
    public void unenroll(Long id) {
        log.info("Dropping enrollment id={}", id);
        Enrollment enrollment = findOrThrow(id);
        enrollment.setStatus(Enrollment.EnrollmentStatus.DROPPED);
        enrollmentRepository.save(enrollment);
    }

    private Enrollment findOrThrow(Long id) {
        return enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found: " + id));
    }

    private EnrollmentResponse mapToResponse(Enrollment e) {
        return EnrollmentResponse.builder()
                .enrollmentId(e.getEnrollmentId())
                .studentId(e.getStudent().getStudentId()).studentName(e.getStudent().getName())
                .courseId(e.getCourse().getCourseId()).courseTitle(e.getCourse().getTitle())
                .enrollmentDate(e.getEnrollmentDate()).status(e.getStatus()).build();
    }
}
