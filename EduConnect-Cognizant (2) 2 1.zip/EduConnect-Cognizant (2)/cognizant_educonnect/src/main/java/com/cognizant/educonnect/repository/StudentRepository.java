package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.entity.UserStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface StudentRepository extends JpaRepository<Student, Long> {
    Optional<Student> findByUserUserId(Long userId);
    List<Student> findByStatus(UserStatus status);
    boolean existsByUserUserId(Long userId);
}
