package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.AssessmentRequest;
import com.cognizant.educonnect.dto.request.GradeRequest;
import com.cognizant.educonnect.dto.request.SubmissionRequest;
import com.cognizant.educonnect.dto.response.AssessmentResponse;
import com.cognizant.educonnect.dto.response.SubmissionResponse;
import java.util.List;

public interface AssessmentService {
    AssessmentResponse createAssessment(AssessmentRequest request);
    AssessmentResponse getAssessmentById(Long id);
    List<AssessmentResponse> getAssessmentsByCourse(Long courseId);
    AssessmentResponse updateAssessment(Long id, AssessmentRequest request);
    void deleteAssessment(Long id);
    SubmissionResponse submitAssessment(SubmissionRequest request);
    List<SubmissionResponse> getSubmissionsByAssessment(Long assessmentId);
    List<SubmissionResponse> getSubmissionsByStudent(Long studentId);
    SubmissionResponse gradeSubmission(Long submissionId, GradeRequest request);
}
