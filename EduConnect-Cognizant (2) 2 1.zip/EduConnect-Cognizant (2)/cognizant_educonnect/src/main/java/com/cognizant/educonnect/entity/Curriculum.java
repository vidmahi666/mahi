package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "curricula")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Curriculum {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long curriculumId;
    @OneToOne @JoinColumn(name = "course_id", nullable = false) private Course course;
    @Column(columnDefinition = "TEXT") private String topicsJson;
    @Enumerated(EnumType.STRING) @Builder.Default private CurriculumStatus status = CurriculumStatus.ACTIVE;
    @CreationTimestamp private LocalDateTime createdAt;
    @UpdateTimestamp  private LocalDateTime updatedAt;
    public enum CurriculumStatus { DRAFT, ACTIVE, ARCHIVED }
}
