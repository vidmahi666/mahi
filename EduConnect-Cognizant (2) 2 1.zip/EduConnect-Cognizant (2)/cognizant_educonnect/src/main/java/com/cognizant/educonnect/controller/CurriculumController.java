package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.entity.Curriculum;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.CourseRepository;
import com.cognizant.educonnect.repository.CurriculumRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/curriculum")
@RequiredArgsConstructor
@Tag(name = "Curriculum", description = "Curriculum management APIs")
public class CurriculumController {

    private final CurriculumRepository curriculumRepository;
    private final CourseRepository courseRepository;

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get curriculum by course")
    public ResponseEntity<ApiResponse<Curriculum>> getByCourse(@PathVariable Long courseId) {
        Curriculum curriculum = curriculumRepository.findByCourseCourseId(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Curriculum not found for course: " + courseId));
        return ResponseEntity.ok(ApiResponse.success(curriculum, "Curriculum retrieved"));
    }

    @PostMapping("/course/{courseId}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Create or update curriculum for course")
    public ResponseEntity<ApiResponse<Curriculum>> upsert(@PathVariable Long courseId,
                                                           @RequestBody String topicsJson) {
        var course = courseRepository.findById(courseId)
                .orElseThrow(() -> new ResourceNotFoundException("Course not found: " + courseId));

        Curriculum curriculum = curriculumRepository.findByCourseCourseId(courseId)
                .orElse(Curriculum.builder().course(course).build());
        curriculum.setTopicsJson(topicsJson);
        return ResponseEntity.ok(ApiResponse.success(curriculumRepository.save(curriculum), "Curriculum saved"));
    }
}
