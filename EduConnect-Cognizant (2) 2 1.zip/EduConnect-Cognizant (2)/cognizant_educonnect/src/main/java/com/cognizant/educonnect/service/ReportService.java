package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.entity.Report.ReportScope;
import java.util.Map;

public interface ReportService {
    Map<String, Object> generateReport(ReportScope scope);
    Map<String, Object> getDashboardMetrics();
}
