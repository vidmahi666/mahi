package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import java.time.LocalDateTime;

@Entity @Table(name = "student_documents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class StudentDocument {
    @Id @GeneratedValue(strategy = GenerationType.IDENTITY) private Long documentId;
    @ManyToOne(fetch = FetchType.LAZY) @JoinColumn(name = "student_id", nullable = false) private Student student;
    @Enumerated(EnumType.STRING) @Column(nullable = false) private DocType docType;
    @Column(nullable = false) private String fileUri;
    @CreationTimestamp private LocalDateTime uploadedDate;
    @Enumerated(EnumType.STRING) @Builder.Default private VerificationStatus verificationStatus = VerificationStatus.PENDING;
    public enum DocType            { ID_PROOF, TRANSCRIPT }
    public enum VerificationStatus { PENDING, VERIFIED, REJECTED }
}
