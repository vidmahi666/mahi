package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.StudentDocument;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface StudentDocumentRepository extends JpaRepository<StudentDocument, Long> {
    List<StudentDocument> findByStudentStudentId(Long studentId);
    List<StudentDocument> findByVerificationStatus(StudentDocument.VerificationStatus status);
}
