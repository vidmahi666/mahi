package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.AssessmentRequest;
import com.cognizant.educonnect.dto.request.GradeRequest;
import com.cognizant.educonnect.dto.request.SubmissionRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.AssessmentResponse;
import com.cognizant.educonnect.dto.response.SubmissionResponse;
import com.cognizant.educonnect.service.AssessmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/assessments")
@RequiredArgsConstructor
@Tag(name = "Assessments", description = "Assessment and submission APIs")
public class AssessmentController {

    private final AssessmentService assessmentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Create assessment")
    public ResponseEntity<ApiResponse<AssessmentResponse>> create(@Valid @RequestBody AssessmentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.createAssessment(request), "Assessment created"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get assessment by ID")
    public ResponseEntity<ApiResponse<AssessmentResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.getAssessmentById(id), "Assessment retrieved"));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get assessments by course")
    public ResponseEntity<ApiResponse<List<AssessmentResponse>>> getByCourse(@PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.getAssessmentsByCourse(courseId), "Assessments retrieved"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update assessment")
    public ResponseEntity<ApiResponse<AssessmentResponse>> update(@PathVariable Long id, @Valid @RequestBody AssessmentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.updateAssessment(id, request), "Assessment updated"));
    }

    @PostMapping("/submit")
    @PreAuthorize("hasRole('STUDENT')")
    @Operation(summary = "Submit assessment")
    public ResponseEntity<ApiResponse<SubmissionResponse>> submit(@Valid @RequestBody SubmissionRequest request) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.submitAssessment(request), "Submitted successfully"));
    }

    @GetMapping("/{assessmentId}/submissions")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Get submissions for assessment")
    public ResponseEntity<ApiResponse<List<SubmissionResponse>>> getSubmissions(@PathVariable Long assessmentId) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.getSubmissionsByAssessment(assessmentId), "Submissions retrieved"));
    }

    @GetMapping("/submissions/student/{studentId}")
    @Operation(summary = "Get submissions by student")
    public ResponseEntity<ApiResponse<List<SubmissionResponse>>> getStudentSubmissions(@PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.getSubmissionsByStudent(studentId), "Submissions retrieved"));
    }

    @PatchMapping("/submissions/{submissionId}/grade")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Grade a submission")
    public ResponseEntity<ApiResponse<SubmissionResponse>> grade(@PathVariable Long submissionId, @Valid @RequestBody GradeRequest request) {
        return ResponseEntity.ok(ApiResponse.success(assessmentService.gradeSubmission(submissionId, request), "Graded successfully"));
    }
}
