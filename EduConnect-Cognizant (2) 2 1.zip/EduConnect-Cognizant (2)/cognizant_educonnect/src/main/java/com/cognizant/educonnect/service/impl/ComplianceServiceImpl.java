package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.ComplianceRecordRequest;
import com.cognizant.educonnect.dto.response.ComplianceRecordResponse;
import com.cognizant.educonnect.entity.ComplianceRecord;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.dto.response.AuditResponse;
import com.cognizant.educonnect.dto.request.AuditRequest;

import com.cognizant.educonnect.repository.ComplianceRecordRepository;
import com.cognizant.educonnect.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepository;

    @Override
    @Transactional
    public ComplianceRecordResponse createRecord(ComplianceRecordRequest request) {
        ComplianceRecord r = ComplianceRecord.builder()
                .entityId(request.getEntityId())
                .type(request.getType())
                .result(request.getResult())
                .notes(request.getNotes())
                .build();
        return mapToResponse(complianceRepository.save(r));
    }
    public List<AuditResponse> getAllAudits(){
        return List.of();
    }
    @Override
    public AuditResponse updateAuditStatus(Long id, String status){
        return null;
    }
    @Override
    public AuditResponse createAudit(AuditRequest request){
        return null;
    }
    @Override
    public List<ComplianceRecordResponse> getAllRecords() {
        return complianceRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<ComplianceRecordResponse> getRecordsByEntity(Long entityId) {
        return complianceRepository.findByEntityId(entityId)
                .stream().map(this::mapToResponse).toList();
    }

    private ComplianceRecordResponse mapToResponse(ComplianceRecord r) {
        return ComplianceRecordResponse.builder()
                .complianceId(r.getComplianceId())
                .entityId(r.getEntityId())
                .type(r.getType())
                .result(r.getResult())
                .recordDate(r.getRecordDate())
                .notes(r.getNotes())
                .build();
    }
}
