package com.educonnect.entity;

public enum UserStatus {
    ACTIVE, INACTIVE, SUSPENDED
}
