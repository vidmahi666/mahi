package com.educonnect.dto.request;

import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SubmissionRequest {
    @NotNull private Long assessmentId;
    @NotNull private Long studentId;
    private String fileUri;
}
