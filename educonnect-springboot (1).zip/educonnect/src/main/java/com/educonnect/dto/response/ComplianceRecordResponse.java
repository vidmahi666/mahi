package com.educonnect.dto.response;

import com.educonnect.entity.ComplianceRecord.ComplianceResult;
import com.educonnect.entity.ComplianceRecord.ComplianceType;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data @Builder
public class ComplianceRecordResponse {
    private Long complianceId;
    private Long entityId;
    private ComplianceType type;
    private ComplianceResult result;
    private LocalDateTime recordDate;
    private String notes;
}
