package com.educonnect.dto.request;

import com.educonnect.entity.Assessment.AssessmentType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;
import java.time.LocalDate;

@Data
public class AssessmentRequest {
    @NotNull private Long courseId;
    @NotBlank private String title;
    @NotNull private AssessmentType type;
    private LocalDate dueDate;
    private Integer maxScore;
}
