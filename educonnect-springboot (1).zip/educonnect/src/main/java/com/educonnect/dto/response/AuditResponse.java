package com.educonnect.dto.response;

import com.educonnect.entity.Audit.AuditStatus;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data @Builder
public class AuditResponse {
    private Long auditId;
    private Long officerId;
    private String officerName;
    private String scope;
    private String findings;
    private LocalDateTime auditDate;
    private AuditStatus status;
}
