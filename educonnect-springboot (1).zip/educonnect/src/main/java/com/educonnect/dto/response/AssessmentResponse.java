package com.educonnect.dto.response;

import com.educonnect.entity.Assessment.AssessmentStatus;
import com.educonnect.entity.Assessment.AssessmentType;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDate;

@Data @Builder
public class AssessmentResponse {
    private Long assessmentId;
    private Long courseId;
    private String courseTitle;
    private String title;
    private AssessmentType type;
    private LocalDate dueDate;
    private Integer maxScore;
    private AssessmentStatus status;
}
