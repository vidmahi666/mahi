package com.educonnect.dto.response;

import com.educonnect.entity.Progress.ProgressStatus;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data @Builder
public class ProgressResponse {
    private Long progressId;
    private Long studentId;
    private String studentName;
    private Long courseId;
    private String courseTitle;
    private Double completionPercentage;
    private String metricsJson;
    private ProgressStatus status;
    private LocalDateTime updatedAt;
}
