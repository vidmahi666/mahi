package com.educonnect.dto.request;

import com.educonnect.entity.ComplianceRecord.ComplianceResult;
import com.educonnect.entity.ComplianceRecord.ComplianceType;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplianceRecordRequest {
    @NotNull private Long entityId;
    @NotNull private ComplianceType type;
    private ComplianceResult result;
    private String notes;
}
