package com.educonnect.dto.request;

import com.educonnect.entity.Content.ContentType;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ContentRequest {
    @NotNull private Long courseId;
    @NotBlank private String title;
    @NotNull private ContentType type;
    private String fileUri;
}
