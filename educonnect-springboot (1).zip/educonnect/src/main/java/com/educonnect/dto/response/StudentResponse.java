package com.educonnect.dto.response;

import com.educonnect.entity.UserStatus;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDate;

@Data @Builder
public class StudentResponse {
    private Long studentId;
    private Long userId;
    private String name;
    private LocalDate dob;
    private String gender;
    private String address;
    private String contactInfo;
    private UserStatus status;
}
