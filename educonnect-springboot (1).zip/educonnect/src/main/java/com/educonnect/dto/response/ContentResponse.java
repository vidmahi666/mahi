package com.educonnect.dto.response;

import com.educonnect.entity.Content.ContentStatus;
import com.educonnect.entity.Content.ContentType;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data @Builder
public class ContentResponse {
    private Long contentId;
    private Long courseId;
    private String courseTitle;
    private String title;
    private ContentType type;
    private String fileUri;
    private LocalDateTime uploadedDate;
    private ContentStatus status;
}
