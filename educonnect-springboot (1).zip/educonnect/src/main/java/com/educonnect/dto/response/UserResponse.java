package com.educonnect.dto.response;

import com.educonnect.entity.Role;
import com.educonnect.entity.UserStatus;
import lombok.Builder;
import lombok.Data;

@Data @Builder
public class UserResponse {
    private Long userId;
    private String name;
    private Role role;
    private String email;
    private String phone;
    private UserStatus status;
}
