package com.educonnect.dto.response;

import com.educonnect.entity.Submission.SubmissionStatus;
import lombok.Builder;
import lombok.Data;
import java.time.LocalDateTime;

@Data @Builder
public class SubmissionResponse {
    private Long submissionId;
    private Long assessmentId;
    private String assessmentTitle;
    private Long studentId;
    private String studentName;
    private String fileUri;
    private LocalDateTime submissionDate;
    private Integer score;
    private String feedback;
    private SubmissionStatus status;
}
