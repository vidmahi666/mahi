package com.educonnect.service.impl;

import com.educonnect.entity.Report;
import com.educonnect.entity.Report.ReportScope;
import com.educonnect.repository.*;
import com.educonnect.service.ReportService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final CourseRepository courseRepository;
    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final AssessmentRepository assessmentRepository;
    private final ComplianceRecordRepository complianceRecordRepository;
    private final ReportRepository reportRepository;

    @Override
    public Map<String, Object> generateReport(ReportScope scope) {
        Map<String, Object> report = new HashMap<>();
        report.put("scope", scope);
        report.put("generatedAt", LocalDateTime.now());

        switch (scope) {
            case COURSE -> {
                report.put("totalCourses", courseRepository.count());
                report.put("activeCourses", courseRepository.findByStatus(com.educonnect.entity.Course.CourseStatus.ACTIVE).size());
            }
            case STUDENT -> {
                report.put("totalStudents", studentRepository.count());
                report.put("activeStudents", studentRepository.findByStatus(com.educonnect.entity.UserStatus.ACTIVE).size());
            }
            case ASSESSMENT -> {
                report.put("totalAssessments", assessmentRepository.count());
            }
            case COMPLIANCE -> {
                report.put("totalRecords", complianceRecordRepository.count());
                report.put("nonCompliant", complianceRecordRepository.findByResult(
                        com.educonnect.entity.ComplianceRecord.ComplianceResult.NON_COMPLIANT).size());
            }
            default -> report.put("message", "Report generated");
        }

        // Persist report
        Report savedReport = Report.builder()
                .scope(scope)
                .metrics(report.toString())
                .generatedBy("system")
                .build();
        reportRepository.save(savedReport);

        return report;
    }

    @Override
    public Map<String, Object> getDashboardMetrics() {
        Map<String, Object> metrics = new HashMap<>();
        metrics.put("totalStudents", studentRepository.count());
        metrics.put("totalCourses", courseRepository.count());
        metrics.put("totalAssessments", assessmentRepository.count());
        metrics.put("totalEnrollments", enrollmentRepository.count());
        metrics.put("complianceRecords", complianceRecordRepository.count());
        metrics.put("generatedAt", LocalDateTime.now());
        return metrics;
    }
}
