package com.educonnect.service.impl;

import com.educonnect.dto.request.EnrollmentRequest;
import com.educonnect.dto.response.EnrollmentResponse;
import com.educonnect.entity.Course;
import com.educonnect.entity.Enrollment;
import com.educonnect.entity.Student;
import com.educonnect.exception.BadRequestException;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.CourseRepository;
import com.educonnect.repository.EnrollmentRepository;
import com.educonnect.repository.StudentRepository;
import com.educonnect.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository studentRepository;
    private final CourseRepository courseRepository;

    @Override
    @Transactional
    public EnrollmentResponse enroll(EnrollmentRequest request) {
        if (enrollmentRepository.existsByStudentStudentIdAndCourseCourseId(request.getStudentId(), request.getCourseId())) {
            throw new BadRequestException("Student already enrolled in this course");
        }
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found"));

        Enrollment enrollment = Enrollment.builder().student(student).course(course).build();
        return mapToResponse(enrollmentRepository.save(enrollment));
    }

    @Override
    public List<EnrollmentResponse> getEnrollmentsByStudent(Long studentId) {
        return enrollmentRepository.findByStudentStudentId(studentId).stream().map(this::mapToResponse).toList();
    }

    @Override
    public List<EnrollmentResponse> getEnrollmentsByCourse(Long courseId) {
        return enrollmentRepository.findByCourseCourseId(courseId).stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public EnrollmentResponse updateStatus(Long id, String status) {
        Enrollment enrollment = enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found: " + id));
        enrollment.setStatus(Enrollment.EnrollmentStatus.valueOf(status.toUpperCase()));
        return mapToResponse(enrollmentRepository.save(enrollment));
    }

    @Override
    @Transactional
    public void unenroll(Long id) {
        Enrollment enrollment = enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Enrollment not found: " + id));
        enrollment.setStatus(Enrollment.EnrollmentStatus.DROPPED);
        enrollmentRepository.save(enrollment);
    }

    private EnrollmentResponse mapToResponse(Enrollment e) {
        return EnrollmentResponse.builder()
                .enrollmentId(e.getEnrollmentId())
                .studentId(e.getStudent().getStudentId())
                .studentName(e.getStudent().getName())
                .courseId(e.getCourse().getCourseId())
                .courseTitle(e.getCourse().getTitle())
                .enrollmentDate(e.getEnrollmentDate())
                .status(e.getStatus())
                .build();
    }
}
