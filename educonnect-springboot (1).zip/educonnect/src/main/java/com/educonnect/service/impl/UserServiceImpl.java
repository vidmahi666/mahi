package com.educonnect.service.impl;

import com.educonnect.dto.response.UserResponse;
import com.educonnect.entity.Role;
import com.educonnect.entity.User;
import com.educonnect.entity.UserStatus;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.UserRepository;
import com.educonnect.service.UserService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class UserServiceImpl implements UserService {

    private final UserRepository userRepository;

    @Override
    public List<UserResponse> getAllUsers() {
        return userRepository.findAll().stream().map(this::mapToResponse).toList();
    }

    @Override
    public UserResponse getUserById(Long id) {
        return mapToResponse(findById(id));
    }

    @Override
    public List<UserResponse> getUsersByRole(Role role) {
        return userRepository.findByRole(role).stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public UserResponse updateUserStatus(Long id, String status) {
        User user = findById(id);
        user.setStatus(UserStatus.valueOf(status.toUpperCase()));
        return mapToResponse(userRepository.save(user));
    }

    @Override
    @Transactional
    public void deleteUser(Long id) {
        User user = findById(id);
        user.setStatus(UserStatus.INACTIVE);
        userRepository.save(user);
    }

    private User findById(Long id) {
        return userRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("User not found: " + id));
    }

    private UserResponse mapToResponse(User u) {
        return UserResponse.builder()
                .userId(u.getUserId()).name(u.getName())
                .role(u.getRole()).email(u.getEmail())
                .phone(u.getPhone()).status(u.getStatus()).build();
    }
}
