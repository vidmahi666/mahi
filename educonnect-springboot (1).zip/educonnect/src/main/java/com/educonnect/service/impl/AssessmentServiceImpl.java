package com.educonnect.service.impl;

import com.educonnect.dto.request.AssessmentRequest;
import com.educonnect.dto.request.GradeRequest;
import com.educonnect.dto.request.SubmissionRequest;
import com.educonnect.dto.response.AssessmentResponse;
import com.educonnect.dto.response.SubmissionResponse;
import com.educonnect.entity.*;
import com.educonnect.exception.BadRequestException;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.*;
import com.educonnect.service.AssessmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AssessmentServiceImpl implements AssessmentService {

    private final AssessmentRepository assessmentRepository;
    private final SubmissionRepository submissionRepository;
    private final CourseRepository courseRepository;
    private final StudentRepository studentRepository;

    @Override
    @Transactional
    public AssessmentResponse createAssessment(AssessmentRequest request) {
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException("Course not found"));
        Assessment assessment = Assessment.builder()
                .course(course).title(request.getTitle())
                .type(request.getType()).dueDate(request.getDueDate())
                .maxScore(request.getMaxScore()).build();
        return mapToResponse(assessmentRepository.save(assessment));
    }

    @Override
    public AssessmentResponse getAssessmentById(Long id) {
        return mapToResponse(findById(id));
    }

    @Override
    public List<AssessmentResponse> getAssessmentsByCourse(Long courseId) {
        return assessmentRepository.findByCourseCourseId(courseId).stream().map(this::mapToResponse).toList();
    }

    @Override
    @Transactional
    public AssessmentResponse updateAssessment(Long id, AssessmentRequest request) {
        Assessment a = findById(id);
        a.setTitle(request.getTitle());
        a.setType(request.getType());
        a.setDueDate(request.getDueDate());
        a.setMaxScore(request.getMaxScore());
        return mapToResponse(assessmentRepository.save(a));
    }

    @Override
    @Transactional
    public void deleteAssessment(Long id) {
        Assessment a = findById(id);
        a.setStatus(Assessment.AssessmentStatus.ARCHIVED);
        assessmentRepository.save(a);
    }

    @Override
    @Transactional
    public SubmissionResponse submitAssessment(SubmissionRequest request) {
        Assessment assessment = findById(request.getAssessmentId());
        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException("Student not found"));

        if (submissionRepository.findByAssessmentAssessmentIdAndStudentStudentId(
                request.getAssessmentId(), request.getStudentId()).isPresent()) {
            throw new BadRequestException("Already submitted");
        }

        Submission submission = Submission.builder()
                .assessment(assessment).student(student)
                .fileUri(request.getFileUri()).build();
        return mapSubResponse(submissionRepository.save(submission));
    }

    @Override
    public List<SubmissionResponse> getSubmissionsByAssessment(Long assessmentId) {
        return submissionRepository.findByAssessmentAssessmentId(assessmentId)
                .stream().map(this::mapSubResponse).toList();
    }

    @Override
    public List<SubmissionResponse> getSubmissionsByStudent(Long studentId) {
        return submissionRepository.findByStudentStudentId(studentId)
                .stream().map(this::mapSubResponse).toList();
    }

    @Override
    @Transactional
    public SubmissionResponse gradeSubmission(Long submissionId, GradeRequest request) {
        Submission submission = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException("Submission not found"));
        submission.setScore(request.getScore());
        submission.setFeedback(request.getFeedback());
        submission.setStatus(Submission.SubmissionStatus.GRADED);
        return mapSubResponse(submissionRepository.save(submission));
    }

    private Assessment findById(Long id) {
        return assessmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Assessment not found: " + id));
    }

    private AssessmentResponse mapToResponse(Assessment a) {
        return AssessmentResponse.builder()
                .assessmentId(a.getAssessmentId()).courseId(a.getCourse().getCourseId())
                .courseTitle(a.getCourse().getTitle()).title(a.getTitle())
                .type(a.getType()).dueDate(a.getDueDate())
                .maxScore(a.getMaxScore()).status(a.getStatus()).build();
    }

    private SubmissionResponse mapSubResponse(Submission s) {
        return SubmissionResponse.builder()
                .submissionId(s.getSubmissionId())
                .assessmentId(s.getAssessment().getAssessmentId())
                .assessmentTitle(s.getAssessment().getTitle())
                .studentId(s.getStudent().getStudentId())
                .studentName(s.getStudent().getName())
                .fileUri(s.getFileUri()).submissionDate(s.getSubmissionDate())
                .score(s.getScore()).feedback(s.getFeedback()).status(s.getStatus()).build();
    }
}
