package com.educonnect.service.impl;

import com.educonnect.dto.request.AuditRequest;
import com.educonnect.dto.request.ComplianceRecordRequest;
import com.educonnect.dto.response.AuditResponse;
import com.educonnect.dto.response.ComplianceRecordResponse;
import com.educonnect.entity.Audit;
import com.educonnect.entity.ComplianceRecord;
import com.educonnect.entity.User;
import com.educonnect.exception.ResourceNotFoundException;
import com.educonnect.repository.AuditRepository;
import com.educonnect.repository.ComplianceRecordRepository;
import com.educonnect.repository.UserRepository;
import com.educonnect.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRecordRepository;
    private final AuditRepository auditRepository;
    private final UserRepository userRepository;

    @Override
    @Transactional
    public ComplianceRecordResponse createRecord(ComplianceRecordRequest request) {
        ComplianceRecord record = ComplianceRecord.builder()
                .entityId(request.getEntityId()).type(request.getType())
                .result(request.getResult()).notes(request.getNotes()).build();
        return mapRecordToResponse(complianceRecordRepository.save(record));
    }

    @Override
    public List<ComplianceRecordResponse> getAllRecords() {
        return complianceRecordRepository.findAll().stream().map(this::mapRecordToResponse).toList();
    }

    @Override
    public List<ComplianceRecordResponse> getRecordsByEntity(Long entityId) {
        return complianceRecordRepository.findByEntityId(entityId).stream().map(this::mapRecordToResponse).toList();
    }

    @Override
    @Transactional
    public AuditResponse createAudit(AuditRequest request) {
        User officer = userRepository.findById(request.getOfficerId())
                .orElseThrow(() -> new ResourceNotFoundException("Officer not found"));
        Audit audit = Audit.builder().officer(officer).scope(request.getScope()).findings(request.getFindings()).build();
        return mapAuditToResponse(auditRepository.save(audit));
    }

    @Override
    public List<AuditResponse> getAllAudits() {
        return auditRepository.findAll().stream().map(this::mapAuditToResponse).toList();
    }

    @Override
    @Transactional
    public AuditResponse updateAuditStatus(Long id, String status) {
        Audit audit = auditRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Audit not found: " + id));
        audit.setStatus(Audit.AuditStatus.valueOf(status.toUpperCase()));
        return mapAuditToResponse(auditRepository.save(audit));
    }

    private ComplianceRecordResponse mapRecordToResponse(ComplianceRecord r) {
        return ComplianceRecordResponse.builder()
                .complianceId(r.getComplianceId()).entityId(r.getEntityId())
                .type(r.getType()).result(r.getResult())
                .recordDate(r.getRecordDate()).notes(r.getNotes()).build();
    }

    private AuditResponse mapAuditToResponse(Audit a) {
        return AuditResponse.builder()
                .auditId(a.getAuditId()).officerId(a.getOfficer().getUserId())
                .officerName(a.getOfficer().getName()).scope(a.getScope())
                .findings(a.getFindings()).auditDate(a.getAuditDate()).status(a.getStatus()).build();
    }
}
