# EduConnect - Digital Education & ELearning Governance System

## Tech Stack
- **Java 21** + **Spring Boot 3.2.5**
- **Spring Security** + **JWT (JJWT 0.12.5)**
- **Spring Data JPA** + **PostgreSQL**
- **Lombok** + **MapStruct**
- **Swagger / OpenAPI 3** (SpringDoc)

## Project Structure
```
src/main/java/com/educonnect/
├── EduConnectApplication.java
├── config/
│   ├── SecurityConfig.java         # Spring Security + JWT filter chain
│   └── OpenApiConfig.java          # Swagger/OpenAPI configuration
├── controller/
│   ├── AuthController.java         # POST /api/auth/register, /login, /refresh
│   ├── UserController.java         # GET/PATCH/DELETE /api/users/**
│   ├── StudentController.java      # GET /api/students/**
│   ├── CourseController.java       # CRUD /api/courses/**
│   ├── EnrollmentController.java   # CRUD /api/enrollments/**
│   ├── ContentController.java      # CRUD /api/content/**
│   ├── AssessmentController.java   # CRUD /api/assessments/** + submissions
│   ├── ProgressController.java     # GET/PUT /api/progress/**
│   ├── ComplianceController.java   # /api/compliance/records + audits
│   ├── ReportController.java       # GET /api/reports/**
│   └── NotificationController.java # /api/notifications/**
├── dto/
│   ├── request/   # LoginRequest, RegisterRequest, CourseRequest, etc.
│   └── response/  # AuthResponse, CourseResponse, ApiResponse<T>, etc.
├── entity/        # JPA entities: User, Student, Course, Content, etc.
├── exception/     # GlobalExceptionHandler, custom exceptions
├── repository/    # Spring Data JPA repositories for each entity
├── security/
│   ├── JwtUtils.java               # JWT generate/validate/extract
│   ├── JwtAuthFilter.java          # OncePerRequestFilter
│   └── UserDetailsServiceImpl.java # Loads user from DB
└── service/
    ├── interfaces/   # AuthService, CourseService, etc.
    └── impl/         # AuthServiceImpl, CourseServiceImpl, etc.
```

## Setup & Run

### 1. Create PostgreSQL Database
```sql
CREATE DATABASE educonnect_db;
```

### 2. Configure application.properties
Update `src/main/resources/application.properties`:
```properties
spring.datasource.url=jdbc:postgresql://localhost:5432/educonnect_db
spring.datasource.username=YOUR_DB_USER
spring.datasource.password=YOUR_DB_PASSWORD
app.jwt.secret=BASE64_ENCODED_256BIT_SECRET
```

### 3. Build & Run
```bash
mvn clean install
mvn spring-boot:run
```

### 4. Swagger UI
Open: http://localhost:8080/swagger-ui.html

## API Endpoints Summary

| Module         | Endpoint Prefix        | Roles Allowed                                      |
|----------------|------------------------|----------------------------------------------------|
| Auth           | /api/auth/**           | Public                                             |
| Users          | /api/users/**          | ADMIN                                              |
| Students       | /api/students/**       | STUDENT, ADMIN, TEACHER                            |
| Courses        | /api/courses/**        | STUDENT (read), TEACHER/ADMIN (write)              |
| Enrollments    | /api/enrollments/**    | All authenticated                                  |
| Content        | /api/content/**        | STUDENT (read), TEACHER/ADMIN (write)              |
| Assessments    | /api/assessments/**    | STUDENT (submit), TEACHER/ADMIN (manage)           |
| Progress       | /api/progress/**       | All authenticated                                  |
| Compliance     | /api/compliance/**     | COMPLIANCE_OFFICER, GOVERNMENT_AUDITOR, ADMIN      |
| Reports        | /api/reports/**        | ADMIN, PROGRAM_MANAGER, COMPLIANCE_OFFICER         |
| Notifications  | /api/notifications/**  | All authenticated                                  |

## Roles
- `STUDENT` — Register, enroll, access content, submit assessments
- `TEACHER` — Create courses, upload content, manage assessments, grade
- `ADMIN` — Full system access, user management
- `PROGRAM_MANAGER` — Program oversight, reports
- `COMPLIANCE_OFFICER` — Compliance records, audits
- `GOVERNMENT_AUDITOR` — Read-only audit and compliance review
