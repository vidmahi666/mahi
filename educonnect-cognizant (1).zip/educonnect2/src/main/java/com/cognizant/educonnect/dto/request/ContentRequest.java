package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.Content;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ContentRequest {

    @NotNull(message = "Course ID is required")
    private Long courseId;

    @NotBlank(message = "Title is required")
    private String title;

    @NotNull(message = "Content type is required")
    private Content.ContentType type;

    @NotBlank(message = "File URI is required")
    private String fileUri;

    private String description;
    private Integer sortOrder;
}
