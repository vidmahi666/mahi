package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.StudentRequest;
import com.cognizant.educonnect.dto.response.StudentResponse;

import java.util.List;

public interface StudentService {
    StudentResponse createProfile(Long userId, StudentRequest request);
    StudentResponse getById(Long id);
    StudentResponse getByUserId(Long userId);
    List<StudentResponse> getAll();
    StudentResponse update(Long id, StudentRequest request);
    void deactivate(Long id);
}
