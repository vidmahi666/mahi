package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.CourseRequest;
import com.cognizant.educonnect.dto.response.CourseResponse;
import com.cognizant.educonnect.entity.Course;

import java.util.List;

public interface CourseService {
    CourseResponse create(CourseRequest request);
    CourseResponse getById(Long id);
    List<CourseResponse> getAll();
    List<CourseResponse> getByTeacher(Long teacherId);
    List<CourseResponse> search(String keyword);
    CourseResponse update(Long id, CourseRequest request);
    CourseResponse updateStatus(Long id, Course.CourseStatus status);
    void delete(Long id);
}
