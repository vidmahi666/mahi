package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.EnrollmentRequest;
import com.cognizant.educonnect.dto.response.EnrollmentResponse;
import com.cognizant.educonnect.entity.Course;
import com.cognizant.educonnect.entity.Enrollment;
import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.CourseRepository;
import com.cognizant.educonnect.repository.EnrollmentRepository;
import com.cognizant.educonnect.repository.StudentRepository;
import com.cognizant.educonnect.service.EnrollmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class EnrollmentServiceImpl implements EnrollmentService {

    private final EnrollmentRepository enrollmentRepository;
    private final StudentRepository    studentRepository;
    private final CourseRepository     courseRepository;

    @Override
    @Transactional
    public EnrollmentResponse enroll(EnrollmentRequest request) {
        if (enrollmentRepository.existsByStudentIdAndCourseId(
                request.getStudentId(), request.getCourseId())) {
            throw new BadRequestException("Student is already enrolled in this course");
        }

        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student not found: " + request.getStudentId()));

        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course not found: " + request.getCourseId()));

        if (course.getStatus() != Course.CourseStatus.PUBLISHED) {
            throw new BadRequestException("Course is not available for enrollment");
        }

        Enrollment enrollment = Enrollment.builder()
                .student(student).course(course)
                .completionPercentage(0.0).build();

        return toResponse(enrollmentRepository.save(enrollment));
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByStudent(Long studentId) {
        return enrollmentRepository.findByStudentId(studentId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<EnrollmentResponse> getByCourse(Long courseId) {
        return enrollmentRepository.findByCourseId(courseId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public EnrollmentResponse updateStatus(Long id, Enrollment.EnrollmentStatus status) {
        Enrollment e = findOrThrow(id);
        e.setStatus(status);
        return toResponse(enrollmentRepository.save(e));
    }

    @Override
    @Transactional
    public EnrollmentResponse updateProgress(Long id, Double percentage) {
        Enrollment e = findOrThrow(id);
        e.setCompletionPercentage(percentage);
        if (percentage >= 100.0) e.setStatus(Enrollment.EnrollmentStatus.COMPLETED);
        return toResponse(enrollmentRepository.save(e));
    }

    @Override
    @Transactional
    public void unenroll(Long id) {
        Enrollment e = findOrThrow(id);
        e.setStatus(Enrollment.EnrollmentStatus.DROPPED);
        enrollmentRepository.save(e);
    }

    // ── Helpers ───────────────────────────────────────────────────
    private Enrollment findOrThrow(Long id) {
        return enrollmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Enrollment not found: " + id));
    }

    private EnrollmentResponse toResponse(Enrollment e) {
        return EnrollmentResponse.builder()
                .id(e.getId())
                .studentId(e.getStudent().getId())
                .studentName(e.getStudent().getName())
                .courseId(e.getCourse().getId())
                .courseTitle(e.getCourse().getTitle())
                .status(e.getStatus())
                .completionPercentage(e.getCompletionPercentage())
                .enrolledAt(e.getEnrolledAt())
                .build();
    }
}
