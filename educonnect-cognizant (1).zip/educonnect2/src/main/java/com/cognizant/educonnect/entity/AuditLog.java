package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "audit_logs",
       indexes = {
           @Index(name = "idx_audit_user",      columnList = "performed_by"),
           @Index(name = "idx_audit_entity",    columnList = "entity_type, entity_id"),
           @Index(name = "idx_audit_timestamp", columnList = "performed_at")
       })
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class AuditLog {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "performed_by")
    private User performedBy;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private AuditAction action;

    @Enumerated(EnumType.STRING)
    private ComplianceRecord.EntityType entityType;

    private Long entityId;

    @Column(columnDefinition = "TEXT")
    private String detail;

    /** IP address of the requester */
    private String ipAddress;

    @CreationTimestamp @Column(name = "performed_at", updatable = false)
    private LocalDateTime performedAt;

    public enum AuditAction {
        CREATE, UPDATE, DELETE, LOGIN, LOGOUT,
        ENROLL, UNENROLL, SUBMIT, GRADE,
        PUBLISH, ARCHIVE, RESOLVE_COMPLIANCE
    }
}
