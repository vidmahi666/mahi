package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.Assessment;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDateTime;

@Data
public class AssessmentRequest {

    @NotNull(message = "Course ID is required")
    private Long courseId;

    @NotNull(message = "Creator (teacher) user ID is required")
    private Long createdByUserId;

    @NotBlank(message = "Title is required")
    private String title;

    private String instructions;

    @NotNull(message = "Assessment type is required")
    private Assessment.AssessmentType type;

    private Integer maxScore;
    private Integer passingScore;
    private LocalDateTime dueDate;
    private Integer durationMinutes;
}
