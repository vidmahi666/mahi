package com.cognizant.educonnect.dto.response;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.Map;

@Data @Builder
public class DashboardResponse {
    // Totals
    private long totalStudents;
    private long totalCourses;
    private long publishedCourses;
    private long totalEnrollments;
    private long completedEnrollments;
    private long totalAssessments;
    private long gradedSubmissions;

    // Compliance
    private long pendingComplianceIssues;
    private long escalatedComplianceIssues;
    private Map<String, Long> complianceByStatus;

    // Audit
    private long auditActionsLast24h;
    private Map<String, Long> auditActionBreakdown;

    // Averages
    private Double avgCourseCompletion;

    private LocalDateTime generatedAt;
}
