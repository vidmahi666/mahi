package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "contents")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Content {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "course_id", nullable = false)
    private Course course;

    @Column(nullable = false)
    private String title;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ContentType type;

    /** Stores URI / path to the file (e.g. S3 key, local path, CDN URL) */
    @Column(nullable = false)
    private String fileUri;

    private String description;

    /** Order of this content within the course */
    private Integer sortOrder;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ContentStatus status = ContentStatus.ACTIVE;

    @CreationTimestamp @Column(updatable = false)
    private LocalDateTime uploadedAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum ContentType  { VIDEO, PDF, DOCUMENT, QUIZ, PRESENTATION, LINK }
    public enum ContentStatus { ACTIVE, INACTIVE, ARCHIVED }
}
