package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Student;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder
public class StudentResponse {
    private Long id;
    private Long userId;
    private String name;
    private String email;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String phone;
    private Student.StudentStatus status;
    private LocalDateTime createdAt;
}
