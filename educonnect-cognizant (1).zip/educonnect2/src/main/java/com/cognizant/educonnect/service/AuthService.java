package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.LoginRequest;
import com.cognizant.educonnect.dto.request.RegisterRequest;
import com.cognizant.educonnect.dto.response.AuthResponse;

public interface AuthService {
    AuthResponse register(RegisterRequest request);
    AuthResponse login(LoginRequest request);
    AuthResponse refreshToken(String refreshToken);
}
