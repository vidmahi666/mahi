package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Assessment;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class AssessmentResponse {
    private Long id;
    private Long courseId;
    private String courseTitle;
    private Long createdById;
    private String createdByName;
    private String title;
    private String instructions;
    private Assessment.AssessmentType type;
    private Integer maxScore;
    private Integer passingScore;
    private LocalDateTime dueDate;
    private Integer durationMinutes;
    private Assessment.AssessmentStatus status;
    private Double averageScore;
    private LocalDateTime createdAt;
}
