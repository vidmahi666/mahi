package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.ComplianceRecord;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplianceRecordRequest {

    @NotNull(message = "Entity type is required")
    private ComplianceRecord.EntityType entityType;

    @NotNull(message = "Entity ID is required")
    private Long entityId;

    @NotBlank(message = "Policy reference is required")
    private String policyReference;

    private String description;

    @NotNull(message = "Raised-by user ID is required")
    private Long raisedByUserId;
}
