package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Content;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class ContentResponse {
    private Long id;
    private Long courseId;
    private String courseTitle;
    private String title;
    private Content.ContentType type;
    private String fileUri;
    private String description;
    private Integer sortOrder;
    private Content.ContentStatus status;
    private LocalDateTime uploadedAt;
}
