package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.CourseRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.CourseResponse;
import com.cognizant.educonnect.entity.Course;
import com.cognizant.educonnect.service.CourseService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/courses")
@RequiredArgsConstructor
@Tag(name = "Courses", description = "Course management")
@SecurityRequirement(name = "Bearer Authentication")
public class CourseController {

    private final CourseService courseService;

    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Create a new course")
    public ResponseEntity<ApiResponse<CourseResponse>> create(
            @Valid @RequestBody CourseRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(courseService.create(request), "Course created"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get course by ID")
    public ResponseEntity<ApiResponse<CourseResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                courseService.getById(id), "Course retrieved"));
    }

    @GetMapping
    @Operation(summary = "Get all courses")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(
                courseService.getAll(), "Courses retrieved"));
    }

    @GetMapping("/teacher/{teacherId}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN','MANAGER')")
    @Operation(summary = "Get courses by teacher")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> getByTeacher(
            @PathVariable Long teacherId) {
        return ResponseEntity.ok(ApiResponse.success(
                courseService.getByTeacher(teacherId), "Courses retrieved"));
    }

    @GetMapping("/search")
    @Operation(summary = "Search courses by title keyword")
    public ResponseEntity<ApiResponse<List<CourseResponse>>> search(
            @RequestParam String keyword) {
        return ResponseEntity.ok(ApiResponse.success(
                courseService.search(keyword), "Search results"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update course details")
    public ResponseEntity<ApiResponse<CourseResponse>> update(
            @PathVariable Long id,
            @Valid @RequestBody CourseRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                courseService.update(id, request), "Course updated"));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update course status (DRAFT / PUBLISHED / ARCHIVED)")
    public ResponseEntity<ApiResponse<CourseResponse>> updateStatus(
            @PathVariable Long id,
            @RequestParam Course.CourseStatus status) {
        return ResponseEntity.ok(ApiResponse.success(
                courseService.updateStatus(id, status), "Status updated"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Archive / soft-delete course")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        courseService.delete(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Course archived"));
    }
}
