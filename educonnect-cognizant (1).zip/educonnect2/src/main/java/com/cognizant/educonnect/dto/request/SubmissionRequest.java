package com.cognizant.educonnect.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class SubmissionRequest {

    @NotNull(message = "Assessment ID is required")
    private Long assessmentId;

    @NotNull(message = "Student ID is required")
    private Long studentId;

    @NotBlank(message = "File URI is required")
    private String fileUri;

    private String remarks;
}
