package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.LoginRequest;
import com.cognizant.educonnect.dto.request.RegisterRequest;
import com.cognizant.educonnect.dto.response.AuthResponse;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.AuthService;
import com.cognizant.educonnect.util.JwtUtil;
import lombok.RequiredArgsConstructor;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service
@RequiredArgsConstructor
public class AuthServiceImpl implements AuthService {

    private final UserRepository       userRepository;
    private final PasswordEncoder      passwordEncoder;
    private final JwtUtil              jwtUtil;
    private final AuthenticationManager authManager;
    private final UserDetailsService   userDetailsService;

    @Override
    @Transactional
    public AuthResponse register(RegisterRequest request) {
        if (userRepository.existsByEmail(request.getEmail())) {
            throw new BadRequestException(
                    "Email already registered: " + request.getEmail());
        }

        User user = User.builder()
                .fullName(request.getFullName())
                .email(request.getEmail())
                .password(passwordEncoder.encode(request.getPassword()))
                .role(request.getRole())
                .enabled(true)
                .build();

        user = userRepository.save(user);
        UserDetails ud = userDetailsService.loadUserByUsername(user.getEmail());

        return buildAuthResponse(user,
                jwtUtil.generateAccessToken(ud),
                jwtUtil.generateRefreshToken(ud));
    }

    @Override
    public AuthResponse login(LoginRequest request) {
        authManager.authenticate(
                new UsernamePasswordAuthenticationToken(
                        request.getEmail(), request.getPassword()));

        User user = userRepository.findByEmail(request.getEmail())
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        UserDetails ud = userDetailsService.loadUserByUsername(user.getEmail());

        return buildAuthResponse(user,
                jwtUtil.generateAccessToken(ud),
                jwtUtil.generateRefreshToken(ud));
    }

    @Override
    public AuthResponse refreshToken(String refreshToken) {
        String email = jwtUtil.extractUsername(refreshToken);
        UserDetails ud = userDetailsService.loadUserByUsername(email);

        if (!jwtUtil.isTokenValid(refreshToken, ud)) {
            throw new BadRequestException("Invalid or expired refresh token");
        }

        User user = userRepository.findByEmail(email)
                .orElseThrow(() -> new ResourceNotFoundException("User not found"));

        return buildAuthResponse(user,
                jwtUtil.generateAccessToken(ud),
                refreshToken);
    }

    // ── Mapper helper ─────────────────────────────────────────────
    private AuthResponse buildAuthResponse(User user,
                                            String accessToken,
                                            String refreshToken) {
        return AuthResponse.builder()
                .userId(user.getId())
                .fullName(user.getFullName())
                .email(user.getEmail())
                .role(user.getRole())
                .accessToken(accessToken)
                .refreshToken(refreshToken)
                .build();
    }
}
