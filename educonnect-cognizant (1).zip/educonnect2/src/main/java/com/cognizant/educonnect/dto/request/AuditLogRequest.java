package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.AuditLog;
import com.cognizant.educonnect.entity.ComplianceRecord;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AuditLogRequest {

    @NotNull(message = "User ID is required")
    private Long userId;

    @NotNull(message = "Action is required")
    private AuditLog.AuditAction action;

    private ComplianceRecord.EntityType entityType;
    private Long entityId;
    private String detail;
    private String ipAddress;
}
