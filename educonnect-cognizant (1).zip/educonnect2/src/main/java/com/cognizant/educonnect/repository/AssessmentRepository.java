package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Assessment;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface AssessmentRepository extends JpaRepository<Assessment, Long> {
    List<Assessment> findByCourseId(Long courseId);
    List<Assessment> findByCreatedById(Long teacherId);
    List<Assessment> findByStatus(Assessment.AssessmentStatus status);

    @Query("SELECT COUNT(a) FROM Assessment a WHERE a.course.id = :courseId")
    long countByCourse(Long courseId);

    @Query("""
            SELECT AVG(s.score)
            FROM Submission s
            WHERE s.assessment.id = :assessmentId
              AND s.score IS NOT NULL
            """)
    Double avgScoreByAssessment(Long assessmentId);
}
