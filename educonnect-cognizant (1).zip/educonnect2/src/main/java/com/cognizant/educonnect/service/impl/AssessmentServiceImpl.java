package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.AssessmentRequest;
import com.cognizant.educonnect.dto.request.GradeRequest;
import com.cognizant.educonnect.dto.request.SubmissionRequest;
import com.cognizant.educonnect.dto.response.AssessmentResponse;
import com.cognizant.educonnect.dto.response.SubmissionResponse;
import com.cognizant.educonnect.entity.*;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.*;
import com.cognizant.educonnect.service.AssessmentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class AssessmentServiceImpl implements AssessmentService {

    private final AssessmentRepository assessmentRepository;
    private final SubmissionRepository  submissionRepository;
    private final CourseRepository      courseRepository;
    private final UserRepository        userRepository;
    private final StudentRepository     studentRepository;

    // ── Assessment CRUD ───────────────────────────────────────────
    @Override
    @Transactional
    public AssessmentResponse create(AssessmentRequest request) {
        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course not found: " + request.getCourseId()));

        User teacher = userRepository.findById(request.getCreatedByUserId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found: " + request.getCreatedByUserId()));

        Assessment assessment = Assessment.builder()
                .course(course).createdBy(teacher)
                .title(request.getTitle())
                .instructions(request.getInstructions())
                .type(request.getType())
                .maxScore(request.getMaxScore())
                .passingScore(request.getPassingScore())
                .dueDate(request.getDueDate())
                .durationMinutes(request.getDurationMinutes())
                .build();

        return toResponse(assessmentRepository.save(assessment));
    }

    @Override
    @Transactional(readOnly = true)
    public AssessmentResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AssessmentResponse> getByCourse(Long courseId) {
        return assessmentRepository.findByCourseId(courseId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public AssessmentResponse update(Long id, AssessmentRequest request) {
        Assessment a = findOrThrow(id);
        a.setTitle(request.getTitle());
        a.setInstructions(request.getInstructions());
        a.setType(request.getType());
        a.setMaxScore(request.getMaxScore());
        a.setPassingScore(request.getPassingScore());
        a.setDueDate(request.getDueDate());
        a.setDurationMinutes(request.getDurationMinutes());
        return toResponse(assessmentRepository.save(a));
    }

    @Override
    @Transactional
    public AssessmentResponse updateStatus(Long id, Assessment.AssessmentStatus status) {
        Assessment a = findOrThrow(id);
        a.setStatus(status);
        return toResponse(assessmentRepository.save(a));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Assessment a = findOrThrow(id);
        a.setStatus(Assessment.AssessmentStatus.ARCHIVED);
        assessmentRepository.save(a);
    }

    // ── Submission operations ─────────────────────────────────────
    @Override
    @Transactional
    public SubmissionResponse submit(SubmissionRequest request) {
        // Validate file URI
        if (!StringUtils.hasText(request.getFileUri())) {
            throw new BadRequestException("Submission file URI must not be blank");
        }

        Assessment assessment = findOrThrow(request.getAssessmentId());

        if (assessment.getStatus() != Assessment.AssessmentStatus.PUBLISHED) {
            throw new BadRequestException("Assessment is not open for submissions");
        }

        if (submissionRepository.existsByAssessmentIdAndStudentId(
                request.getAssessmentId(), request.getStudentId())) {
            throw new BadRequestException("Student has already submitted this assessment");
        }

        Student student = studentRepository.findById(request.getStudentId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student not found: " + request.getStudentId()));

        Submission submission = Submission.builder()
                .assessment(assessment)
                .student(student)
                .fileUri(request.getFileUri())
                .remarks(request.getRemarks())
                .build();

        return toSubResponse(submissionRepository.save(submission));
    }

    @Override
    @Transactional
    public SubmissionResponse grade(Long submissionId, GradeRequest request) {
        Submission submission = submissionRepository.findById(submissionId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Submission not found: " + submissionId));

        Integer maxScore = submission.getAssessment().getMaxScore();
        if (maxScore != null && request.getScore() > maxScore) {
            throw new BadRequestException(
                    "Score " + request.getScore() + " exceeds max score " + maxScore);
        }

        submission.setScore(request.getScore());
        submission.setFeedback(request.getFeedback());
        submission.setStatus(Submission.SubmissionStatus.GRADED);
        return toSubResponse(submissionRepository.save(submission));
    }

    @Override
    @Transactional(readOnly = true)
    public List<SubmissionResponse> getSubmissionsByAssessment(Long assessmentId) {
        return submissionRepository.findByAssessmentId(assessmentId)
                .stream().map(this::toSubResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<SubmissionResponse> getSubmissionsByStudent(Long studentId) {
        return submissionRepository.findByStudentId(studentId)
                .stream().map(this::toSubResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public SubmissionResponse getSubmissionById(Long id) {
        return toSubResponse(submissionRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Submission not found: " + id)));
    }

    // ── Helpers ───────────────────────────────────────────────────
    private Assessment findOrThrow(Long id) {
        return assessmentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Assessment not found: " + id));
    }

    private AssessmentResponse toResponse(Assessment a) {
        return AssessmentResponse.builder()
                .id(a.getId())
                .courseId(a.getCourse().getId())
                .courseTitle(a.getCourse().getTitle())
                .createdById(a.getCreatedBy().getId())
                .createdByName(a.getCreatedBy().getFullName())
                .title(a.getTitle())
                .instructions(a.getInstructions())
                .type(a.getType())
                .maxScore(a.getMaxScore())
                .passingScore(a.getPassingScore())
                .dueDate(a.getDueDate())
                .durationMinutes(a.getDurationMinutes())
                .status(a.getStatus())
                .averageScore(assessmentRepository.avgScoreByAssessment(a.getId()))
                .createdAt(a.getCreatedAt())
                .build();
    }

    private SubmissionResponse toSubResponse(Submission s) {
        return SubmissionResponse.builder()
                .id(s.getId())
                .assessmentId(s.getAssessment().getId())
                .assessmentTitle(s.getAssessment().getTitle())
                .studentId(s.getStudent().getId())
                .studentName(s.getStudent().getName())
                .fileUri(s.getFileUri())
                .remarks(s.getRemarks())
                .score(s.getScore())
                .feedback(s.getFeedback())
                .status(s.getStatus())
                .submittedAt(s.getSubmittedAt())
                .updatedAt(s.getUpdatedAt())
                .build();
    }
}
