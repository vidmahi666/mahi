package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.ComplianceRecordRequest;
import com.cognizant.educonnect.dto.request.ComplianceResolveRequest;
import com.cognizant.educonnect.dto.response.ComplianceRecordResponse;
import com.cognizant.educonnect.entity.ComplianceRecord;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.ComplianceRecordRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.ComplianceService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class ComplianceServiceImpl implements ComplianceService {

    private final ComplianceRecordRepository complianceRepository;
    private final UserRepository             userRepository;

    @Override
    @Transactional
    public ComplianceRecordResponse create(ComplianceRecordRequest request) {
        User officer = userRepository.findById(request.getRaisedByUserId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found: " + request.getRaisedByUserId()));

        ComplianceRecord record = ComplianceRecord.builder()
                .entityType(request.getEntityType())
                .entityId(request.getEntityId())
                .policyReference(request.getPolicyReference())
                .description(request.getDescription())
                .raisedBy(officer)
                .build();

        return toResponse(complianceRepository.save(record));
    }

    @Override
    @Transactional(readOnly = true)
    public ComplianceRecordResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ComplianceRecordResponse> getAll() {
        return complianceRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ComplianceRecordResponse> getByStatus(
            ComplianceRecord.ComplianceStatus status) {
        return complianceRepository.findByStatus(status)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ComplianceRecordResponse> getByEntity(
            ComplianceRecord.EntityType type, Long entityId) {
        return complianceRepository.findByEntityTypeAndEntityId(type, entityId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public ComplianceRecordResponse resolve(Long id, ComplianceResolveRequest request) {
        ComplianceRecord record = findOrThrow(id);
        record.setStatus(request.getStatus());
        record.setResolution(request.getResolution());
        if (request.getStatus() == ComplianceRecord.ComplianceStatus.RESOLVED ||
            request.getStatus() == ComplianceRecord.ComplianceStatus.CLOSED) {
            record.setResolvedAt(LocalDateTime.now());
        }
        return toResponse(complianceRepository.save(record));
    }

    // ── Helpers ───────────────────────────────────────────────────
    private ComplianceRecord findOrThrow(Long id) {
        return complianceRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Compliance record not found: " + id));
    }

    private ComplianceRecordResponse toResponse(ComplianceRecord r) {
        return ComplianceRecordResponse.builder()
                .id(r.getId())
                .entityType(r.getEntityType())
                .entityId(r.getEntityId())
                .policyReference(r.getPolicyReference())
                .description(r.getDescription())
                .status(r.getStatus())
                .raisedById(r.getRaisedBy() != null ? r.getRaisedBy().getId() : null)
                .raisedByName(r.getRaisedBy() != null ? r.getRaisedBy().getFullName() : null)
                .resolution(r.getResolution())
                .resolvedAt(r.getResolvedAt())
                .createdAt(r.getCreatedAt())
                .build();
    }
}
