package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.ComplianceRecord;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ComplianceRecordRepository
        extends JpaRepository<ComplianceRecord, Long> {

    List<ComplianceRecord> findByEntityTypeAndEntityId(
            ComplianceRecord.EntityType entityType, Long entityId);

    List<ComplianceRecord> findByStatus(ComplianceRecord.ComplianceStatus status);

    List<ComplianceRecord> findByRaisedById(Long userId);

    @Query("SELECT COUNT(c) FROM ComplianceRecord c WHERE c.status = 'PENDING'")
    long countPending();

    @Query("SELECT COUNT(c) FROM ComplianceRecord c WHERE c.status = 'ESCALATED'")
    long countEscalated();

    @Query("""
            SELECT c.status, COUNT(c)
            FROM ComplianceRecord c
            GROUP BY c.status
            """)
    List<Object[]> countGroupedByStatus();
}
