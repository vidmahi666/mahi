package com.cognizant.educonnect.dto.request;

import com.cognizant.educonnect.entity.ComplianceRecord;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ComplianceResolveRequest {
    @NotNull
    private ComplianceRecord.ComplianceStatus status;
    private String resolution;
}
