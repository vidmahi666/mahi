package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.AssessmentRequest;
import com.cognizant.educonnect.dto.request.GradeRequest;
import com.cognizant.educonnect.dto.request.SubmissionRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.AssessmentResponse;
import com.cognizant.educonnect.dto.response.SubmissionResponse;
import com.cognizant.educonnect.entity.Assessment;
import com.cognizant.educonnect.service.AssessmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/assessments")
@RequiredArgsConstructor
@Tag(name = "Assessments & Submissions", description = "Assessment creation and student submission handling")
@SecurityRequirement(name = "Bearer Authentication")
public class AssessmentController {

    private final AssessmentService assessmentService;

    // ── Assessment endpoints ──────────────────────────────────────
    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Create a new assessment")
    public ResponseEntity<ApiResponse<AssessmentResponse>> create(
            @Valid @RequestBody AssessmentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(assessmentService.create(request), "Assessment created"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get assessment by ID")
    public ResponseEntity<ApiResponse<AssessmentResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.getById(id), "Assessment retrieved"));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get all assessments for a course")
    public ResponseEntity<ApiResponse<List<AssessmentResponse>>> getByCourse(
            @PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.getByCourse(courseId), "Assessments retrieved"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update assessment details")
    public ResponseEntity<ApiResponse<AssessmentResponse>> update(
            @PathVariable Long id,
            @Valid @RequestBody AssessmentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.update(id, request), "Assessment updated"));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update assessment status (DRAFT / PUBLISHED / CLOSED / ARCHIVED)")
    public ResponseEntity<ApiResponse<AssessmentResponse>> updateStatus(
            @PathVariable Long id,
            @RequestParam Assessment.AssessmentStatus status) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.updateStatus(id, status), "Status updated"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Archive assessment")
    public ResponseEntity<ApiResponse<Void>> delete(@PathVariable Long id) {
        assessmentService.delete(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Assessment archived"));
    }

    // ── Submission endpoints ──────────────────────────────────────
    @PostMapping("/submissions")
    @PreAuthorize("hasAnyRole('STUDENT','ADMIN')")
    @Operation(summary = "Student submits an assessment (fileUri required)")
    public ResponseEntity<ApiResponse<SubmissionResponse>> submit(
            @Valid @RequestBody SubmissionRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(assessmentService.submit(request), "Submitted successfully"));
    }

    @PatchMapping("/submissions/{submissionId}/grade")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Teacher grades a submission")
    public ResponseEntity<ApiResponse<SubmissionResponse>> grade(
            @PathVariable Long submissionId,
            @Valid @RequestBody GradeRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.grade(submissionId, request), "Submission graded"));
    }

    @GetMapping("/{assessmentId}/submissions")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Get all submissions for an assessment")
    public ResponseEntity<ApiResponse<List<SubmissionResponse>>> getSubmissions(
            @PathVariable Long assessmentId) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.getSubmissionsByAssessment(assessmentId),
                "Submissions retrieved"));
    }

    @GetMapping("/submissions/student/{studentId}")
    @PreAuthorize("hasAnyRole('STUDENT','TEACHER','ADMIN')")
    @Operation(summary = "Get all submissions by a student")
    public ResponseEntity<ApiResponse<List<SubmissionResponse>>> getByStudent(
            @PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.getSubmissionsByStudent(studentId),
                "Submissions retrieved"));
    }

    @GetMapping("/submissions/{id}")
    @Operation(summary = "Get a single submission by ID")
    public ResponseEntity<ApiResponse<SubmissionResponse>> getSubmission(
            @PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                assessmentService.getSubmissionById(id), "Submission retrieved"));
    }
}
