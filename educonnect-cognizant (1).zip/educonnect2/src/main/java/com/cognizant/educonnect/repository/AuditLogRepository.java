package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.AuditLog;
import com.cognizant.educonnect.entity.ComplianceRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, Long> {

    Page<AuditLog> findByPerformedById(Long userId, Pageable pageable);

    List<AuditLog> findByEntityTypeAndEntityId(
            ComplianceRecord.EntityType entityType, Long entityId);

    List<AuditLog> findByAction(AuditLog.AuditAction action);

    @Query("""
            SELECT a FROM AuditLog a
            WHERE a.performedAt BETWEEN :from AND :to
            ORDER BY a.performedAt DESC
            """)
    List<AuditLog> findByDateRange(LocalDateTime from, LocalDateTime to);

    @Query("""
            SELECT a.action, COUNT(a)
            FROM AuditLog a
            GROUP BY a.action
            ORDER BY COUNT(a) DESC
            """)
    List<Object[]> countGroupedByAction();

    @Query("""
            SELECT COUNT(a) FROM AuditLog a
            WHERE a.performedAt >= :since
            """)
    long countSince(LocalDateTime since);
}
