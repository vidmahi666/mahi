package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "reports")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class Report {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private ReportScope scope;

    @Column(nullable = false)
    private String title;

    /** Serialised JSON snapshot of metrics at time of generation */
    @Column(columnDefinition = "TEXT")
    private String metricsJson;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "generated_by")
    private User generatedBy;

    @CreationTimestamp @Column(updatable = false)
    private LocalDateTime generatedAt;

    public enum ReportScope {
        COURSE, STUDENT, ASSESSMENT, COMPLIANCE, ENROLLMENT, DASHBOARD
    }
}
