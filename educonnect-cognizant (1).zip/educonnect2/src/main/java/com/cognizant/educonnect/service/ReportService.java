package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.response.DashboardResponse;
import com.cognizant.educonnect.dto.response.ReportResponse;
import com.cognizant.educonnect.entity.Report;

import java.util.List;

public interface ReportService {
    DashboardResponse getDashboard();
    ReportResponse generateAndSave(Report.ReportScope scope, Long generatedByUserId);
    List<ReportResponse> getAll();
    List<ReportResponse> getByScope(Report.ReportScope scope);
    ReportResponse getById(Long id);
}
