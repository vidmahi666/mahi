package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.AssessmentRequest;
import com.cognizant.educonnect.dto.request.GradeRequest;
import com.cognizant.educonnect.dto.request.SubmissionRequest;
import com.cognizant.educonnect.dto.response.AssessmentResponse;
import com.cognizant.educonnect.dto.response.SubmissionResponse;
import com.cognizant.educonnect.entity.Assessment;

import java.util.List;

public interface AssessmentService {
    AssessmentResponse create(AssessmentRequest request);
    AssessmentResponse getById(Long id);
    List<AssessmentResponse> getByCourse(Long courseId);
    AssessmentResponse update(Long id, AssessmentRequest request);
    AssessmentResponse updateStatus(Long id, Assessment.AssessmentStatus status);
    void delete(Long id);

    // Submission operations
    SubmissionResponse submit(SubmissionRequest request);
    SubmissionResponse grade(Long submissionId, GradeRequest request);
    List<SubmissionResponse> getSubmissionsByAssessment(Long assessmentId);
    List<SubmissionResponse> getSubmissionsByStudent(Long studentId);
    SubmissionResponse getSubmissionById(Long id);
}
