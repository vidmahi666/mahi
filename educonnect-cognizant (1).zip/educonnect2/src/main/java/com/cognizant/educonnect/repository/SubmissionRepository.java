package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Submission;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface SubmissionRepository extends JpaRepository<Submission, Long> {
    List<Submission> findByAssessmentId(Long assessmentId);
    List<Submission> findByStudentId(Long studentId);
    Optional<Submission> findByAssessmentIdAndStudentId(Long assessmentId, Long studentId);
    boolean existsByAssessmentIdAndStudentId(Long assessmentId, Long studentId);

    @Query("SELECT COUNT(s) FROM Submission s WHERE s.status = 'GRADED'")
    long countGraded();

    @Query("""
            SELECT AVG(s.score)
            FROM Submission s
            WHERE s.student.id = :studentId
              AND s.score IS NOT NULL
            """)
    Double avgScoreByStudent(Long studentId);
}
