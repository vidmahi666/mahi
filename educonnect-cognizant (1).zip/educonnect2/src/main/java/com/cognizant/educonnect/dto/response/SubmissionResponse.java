package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Submission;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class SubmissionResponse {
    private Long id;
    private Long assessmentId;
    private String assessmentTitle;
    private Long studentId;
    private String studentName;
    private String fileUri;
    private String remarks;
    private Integer score;
    private String feedback;
    private Submission.SubmissionStatus status;
    private LocalDateTime submittedAt;
    private LocalDateTime updatedAt;
}
