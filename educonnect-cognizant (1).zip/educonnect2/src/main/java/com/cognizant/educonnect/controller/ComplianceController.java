package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.ComplianceRecordRequest;
import com.cognizant.educonnect.dto.request.ComplianceResolveRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.ComplianceRecordResponse;
import com.cognizant.educonnect.entity.ComplianceRecord;
import com.cognizant.educonnect.service.ComplianceService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/compliance")
@RequiredArgsConstructor
@Tag(name = "Compliance", description = "Compliance record management")
@SecurityRequirement(name = "Bearer Authentication")
public class ComplianceController {

    private final ComplianceService complianceService;

    @PostMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    @Operation(summary = "Raise a new compliance record")
    public ResponseEntity<ApiResponse<ComplianceRecordResponse>> create(
            @Valid @RequestBody ComplianceRecordRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(complianceService.create(request),
                        "Compliance record raised"));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN','MANAGER')")
    @Operation(summary = "Get all compliance records")
    public ResponseEntity<ApiResponse<List<ComplianceRecordResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(
                complianceService.getAll(), "Records retrieved"));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    @Operation(summary = "Get compliance record by ID")
    public ResponseEntity<ApiResponse<ComplianceRecordResponse>> getById(
            @PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                complianceService.getById(id), "Record retrieved"));
    }

    @GetMapping("/status/{status}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN','MANAGER')")
    @Operation(summary = "Filter compliance records by status")
    public ResponseEntity<ApiResponse<List<ComplianceRecordResponse>>> getByStatus(
            @PathVariable ComplianceRecord.ComplianceStatus status) {
        return ResponseEntity.ok(ApiResponse.success(
                complianceService.getByStatus(status), "Records retrieved"));
    }

    @GetMapping("/entity/{type}/{entityId}")
    @PreAuthorize("hasAnyRole('COMPLIANCE','AUDITOR','ADMIN')")
    @Operation(summary = "Get compliance records for a specific entity")
    public ResponseEntity<ApiResponse<List<ComplianceRecordResponse>>> getByEntity(
            @PathVariable ComplianceRecord.EntityType type,
            @PathVariable Long entityId) {
        return ResponseEntity.ok(ApiResponse.success(
                complianceService.getByEntity(type, entityId), "Records retrieved"));
    }

    @PatchMapping("/{id}/resolve")
    @PreAuthorize("hasAnyRole('COMPLIANCE','ADMIN')")
    @Operation(summary = "Resolve or escalate a compliance record")
    public ResponseEntity<ApiResponse<ComplianceRecordResponse>> resolve(
            @PathVariable Long id,
            @Valid @RequestBody ComplianceResolveRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                complianceService.resolve(id, request), "Record updated"));
    }
}
