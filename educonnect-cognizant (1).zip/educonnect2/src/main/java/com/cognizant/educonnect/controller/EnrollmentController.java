package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.EnrollmentRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.EnrollmentResponse;
import com.cognizant.educonnect.entity.Enrollment;
import com.cognizant.educonnect.service.EnrollmentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/enrollments")
@RequiredArgsConstructor
@Tag(name = "Enrollments", description = "Course enrollment management")
@SecurityRequirement(name = "Bearer Authentication")
public class EnrollmentController {

    private final EnrollmentService enrollmentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('STUDENT','ADMIN')")
    @Operation(summary = "Enroll student into a course")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> enroll(
            @Valid @RequestBody EnrollmentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(enrollmentService.enroll(request), "Enrolled successfully"));
    }

    @GetMapping("/student/{studentId}")
    @PreAuthorize("hasAnyRole('STUDENT','ADMIN','TEACHER')")
    @Operation(summary = "Get all enrollments for a student")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByStudent(
            @PathVariable Long studentId) {
        return ResponseEntity.ok(ApiResponse.success(
                enrollmentService.getByStudent(studentId), "Enrollments retrieved"));
    }

    @GetMapping("/course/{courseId}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN','MANAGER')")
    @Operation(summary = "Get all enrollments for a course")
    public ResponseEntity<ApiResponse<List<EnrollmentResponse>>> getByCourse(
            @PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(
                enrollmentService.getByCourse(courseId), "Enrollments retrieved"));
    }

    @PatchMapping("/{id}/status")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update enrollment status")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> updateStatus(
            @PathVariable Long id,
            @RequestParam Enrollment.EnrollmentStatus status) {
        return ResponseEntity.ok(ApiResponse.success(
                enrollmentService.updateStatus(id, status), "Status updated"));
    }

    @PatchMapping("/{id}/progress")
    @PreAuthorize("hasAnyRole('STUDENT','TEACHER','ADMIN')")
    @Operation(summary = "Update completion percentage (0-100)")
    public ResponseEntity<ApiResponse<EnrollmentResponse>> updateProgress(
            @PathVariable Long id,
            @RequestParam Double percentage) {
        return ResponseEntity.ok(ApiResponse.success(
                enrollmentService.updateProgress(id, percentage), "Progress updated"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('STUDENT','ADMIN')")
    @Operation(summary = "Unenroll (drop) from course")
    public ResponseEntity<ApiResponse<Void>> unenroll(@PathVariable Long id) {
        enrollmentService.unenroll(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Unenrolled successfully"));
    }
}
