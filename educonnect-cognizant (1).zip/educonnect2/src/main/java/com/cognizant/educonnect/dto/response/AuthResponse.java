package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Role;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class AuthResponse {
    private Long userId;
    private String fullName;
    private String email;
    private Role role;
    private String accessToken;
    private String refreshToken;
    @Builder.Default
    private String tokenType = "Bearer";
}
