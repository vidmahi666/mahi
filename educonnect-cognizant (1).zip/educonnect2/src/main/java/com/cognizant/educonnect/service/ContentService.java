package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.ContentRequest;
import com.cognizant.educonnect.dto.response.ContentResponse;

import java.util.List;

public interface ContentService {
    ContentResponse upload(ContentRequest request);
    ContentResponse getById(Long id);
    List<ContentResponse> getByCourse(Long courseId);
    ContentResponse update(Long id, ContentRequest request);
    void archive(Long id);
}
