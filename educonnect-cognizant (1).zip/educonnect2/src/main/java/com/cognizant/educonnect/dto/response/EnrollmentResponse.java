package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Enrollment;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class EnrollmentResponse {
    private Long id;
    private Long studentId;
    private String studentName;
    private Long courseId;
    private String courseTitle;
    private Enrollment.EnrollmentStatus status;
    private Double completionPercentage;
    private LocalDateTime enrolledAt;
}
