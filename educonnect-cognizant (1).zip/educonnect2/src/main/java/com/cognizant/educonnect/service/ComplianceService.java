package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.ComplianceRecordRequest;
import com.cognizant.educonnect.dto.request.ComplianceResolveRequest;
import com.cognizant.educonnect.dto.response.ComplianceRecordResponse;
import com.cognizant.educonnect.entity.ComplianceRecord;

import java.util.List;

public interface ComplianceService {
    ComplianceRecordResponse create(ComplianceRecordRequest request);
    ComplianceRecordResponse getById(Long id);
    List<ComplianceRecordResponse> getAll();
    List<ComplianceRecordResponse> getByStatus(ComplianceRecord.ComplianceStatus status);
    List<ComplianceRecordResponse> getByEntity(ComplianceRecord.EntityType type, Long entityId);
    ComplianceRecordResponse resolve(Long id, ComplianceResolveRequest request);
}
