package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.AuditLog;
import com.cognizant.educonnect.entity.ComplianceRecord;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class AuditLogResponse {
    private Long id;
    private Long performedById;
    private String performedByName;
    private AuditLog.AuditAction action;
    private ComplianceRecord.EntityType entityType;
    private Long entityId;
    private String detail;
    private String ipAddress;
    private LocalDateTime performedAt;
}
