package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Course;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDate;
import java.time.LocalDateTime;

@Data @Builder
public class CourseResponse {
    private Long id;
    private String title;
    private String description;
    private Long teacherId;
    private String teacherName;
    private LocalDate startDate;
    private LocalDate endDate;
    private Course.CourseStatus status;
    private long enrollmentCount;
    private LocalDateTime createdAt;
}
