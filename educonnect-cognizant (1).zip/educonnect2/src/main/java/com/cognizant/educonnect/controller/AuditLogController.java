package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.AuditLogRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.AuditLogResponse;
import com.cognizant.educonnect.entity.ComplianceRecord;
import com.cognizant.educonnect.service.AuditLogService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDateTime;
import java.util.List;

@RestController
@RequestMapping("/api/v1/audit-logs")
@RequiredArgsConstructor
@Tag(name = "Audit Logs", description = "Immutable audit trail management")
@SecurityRequirement(name = "Bearer Authentication")
public class AuditLogController {

    private final AuditLogService auditLogService;

    @PostMapping
    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN')")
    @Operation(summary = "Manually record an audit event")
    public ResponseEntity<ApiResponse<AuditLogResponse>> log(
            @Valid @RequestBody AuditLogRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(
                        auditLogService.log(
                                request.getUserId(),
                                request.getAction(),
                                request.getEntityType(),
                                request.getEntityId(),
                                request.getDetail(),
                                request.getIpAddress()),
                        "Audit log created"));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN')")
    @Operation(summary = "Get all audit logs")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(
                auditLogService.getAll(), "Audit logs retrieved"));
    }

    @GetMapping("/user/{userId}")
    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN')")
    @Operation(summary = "Get paginated audit logs for a user")
    public ResponseEntity<ApiResponse<Page<AuditLogResponse>>> getByUser(
            @PathVariable Long userId,
            @PageableDefault(size = 20, sort = "performedAt") Pageable pageable) {
        return ResponseEntity.ok(ApiResponse.success(
                auditLogService.getByUser(userId, pageable), "Logs retrieved"));
    }

    @GetMapping("/entity/{type}/{entityId}")
    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN')")
    @Operation(summary = "Get audit logs for a specific entity")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getByEntity(
            @PathVariable ComplianceRecord.EntityType type,
            @PathVariable Long entityId) {
        return ResponseEntity.ok(ApiResponse.success(
                auditLogService.getByEntity(type, entityId), "Logs retrieved"));
    }

    @GetMapping("/date-range")
    @PreAuthorize("hasAnyRole('AUDITOR','ADMIN')")
    @Operation(summary = "Get audit logs within a date-time range")
    public ResponseEntity<ApiResponse<List<AuditLogResponse>>> getByRange(
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime from,
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME)
            LocalDateTime to) {
        return ResponseEntity.ok(ApiResponse.success(
                auditLogService.getByDateRange(from, to), "Logs retrieved"));
    }
}
