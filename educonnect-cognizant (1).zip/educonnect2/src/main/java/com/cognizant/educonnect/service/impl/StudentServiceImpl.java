package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.StudentRequest;
import com.cognizant.educonnect.dto.response.StudentResponse;
import com.cognizant.educonnect.entity.Student;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.StudentRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.StudentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class StudentServiceImpl implements StudentService {

    private final StudentRepository studentRepository;
    private final UserRepository    userRepository;

    @Override
    @Transactional
    public StudentResponse createProfile(Long userId, StudentRequest request) {
        if (studentRepository.existsByUserId(userId)) {
            throw new BadRequestException(
                    "Student profile already exists for user: " + userId);
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found: " + userId));

        Student student = Student.builder()
                .user(user).name(request.getName())
                .dateOfBirth(request.getDateOfBirth())
                .gender(request.getGender()).address(request.getAddress())
                .phone(request.getPhone()).build();

        return toResponse(studentRepository.save(student));
    }

    @Override
    @Transactional(readOnly = true)
    public StudentResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public StudentResponse getByUserId(Long userId) {
        return toResponse(studentRepository.findByUserId(userId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student profile not found for user: " + userId)));
    }

    @Override
    @Transactional(readOnly = true)
    public List<StudentResponse> getAll() {
        return studentRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public StudentResponse update(Long id, StudentRequest request) {
        Student student = findOrThrow(id);
        student.setName(request.getName());
        student.setDateOfBirth(request.getDateOfBirth());
        student.setGender(request.getGender());
        student.setAddress(request.getAddress());
        student.setPhone(request.getPhone());
        return toResponse(studentRepository.save(student));
    }

    @Override
    @Transactional
    public void deactivate(Long id) {
        Student student = findOrThrow(id);
        student.setStatus(Student.StudentStatus.INACTIVE);
        studentRepository.save(student);
    }

    // ── Helpers ───────────────────────────────────────────────────
    private Student findOrThrow(Long id) {
        return studentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Student not found: " + id));
    }

    private StudentResponse toResponse(Student s) {
        return StudentResponse.builder()
                .id(s.getId())
                .userId(s.getUser().getId())
                .name(s.getName())
                .email(s.getUser().getEmail())
                .dateOfBirth(s.getDateOfBirth())
                .gender(s.getGender())
                .address(s.getAddress())
                .phone(s.getPhone())
                .status(s.getStatus())
                .createdAt(s.getCreatedAt())
                .build();
    }
}
