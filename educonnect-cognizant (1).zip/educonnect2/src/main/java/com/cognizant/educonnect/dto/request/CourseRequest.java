package com.cognizant.educonnect.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.time.LocalDate;

@Data
public class CourseRequest {
    @NotBlank(message = "Title is required")
    private String title;

    private String description;

    @NotNull(message = "Teacher ID is required")
    private Long teacherId;

    private LocalDate startDate;
    private LocalDate endDate;
}
