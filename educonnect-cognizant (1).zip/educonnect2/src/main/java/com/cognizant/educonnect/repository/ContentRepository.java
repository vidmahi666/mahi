package com.cognizant.educonnect.repository;

import com.cognizant.educonnect.entity.Content;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface ContentRepository extends JpaRepository<Content, Long> {
    List<Content> findByCourseIdOrderBySortOrderAsc(Long courseId);
    List<Content> findByCourseIdAndStatus(Long courseId, Content.ContentStatus status);
    List<Content> findByType(Content.ContentType type);

    @Query("SELECT COUNT(c) FROM Content c WHERE c.course.id = :courseId AND c.status = 'ACTIVE'")
    long countActiveByCourse(Long courseId);

    boolean existsByFileUri(String fileUri);
}
