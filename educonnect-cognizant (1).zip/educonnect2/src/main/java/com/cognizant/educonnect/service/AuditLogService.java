package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.response.AuditLogResponse;
import com.cognizant.educonnect.entity.AuditLog;
import com.cognizant.educonnect.entity.ComplianceRecord;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.time.LocalDateTime;
import java.util.List;

public interface AuditLogService {
    AuditLogResponse log(Long userId, AuditLog.AuditAction action,
                          ComplianceRecord.EntityType entityType,
                          Long entityId, String detail, String ipAddress);

    Page<AuditLogResponse> getByUser(Long userId, Pageable pageable);
    List<AuditLogResponse> getByEntity(ComplianceRecord.EntityType type, Long entityId);
    List<AuditLogResponse> getByDateRange(LocalDateTime from, LocalDateTime to);
    List<AuditLogResponse> getAll();
}
