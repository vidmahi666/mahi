package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.response.DashboardResponse;
import com.cognizant.educonnect.dto.response.ReportResponse;
import com.cognizant.educonnect.entity.Report;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.*;
import com.cognizant.educonnect.service.ReportService;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Slf4j
@Service
@RequiredArgsConstructor
public class ReportServiceImpl implements ReportService {

    private final StudentRepository          studentRepository;
    private final CourseRepository           courseRepository;
    private final EnrollmentRepository       enrollmentRepository;
    private final AssessmentRepository       assessmentRepository;
    private final SubmissionRepository       submissionRepository;
    private final ComplianceRecordRepository complianceRepository;
    private final AuditLogRepository         auditLogRepository;
    private final ReportRepository           reportRepository;
    private final UserRepository             userRepository;

    // Injected shared bean from AppConfiguration
    private final ObjectMapper objectMapper;

    // ── Dashboard ─────────────────────────────────────────────────
    @Override
    @Transactional(readOnly = true)
    public DashboardResponse getDashboard() {

        Map<String, Long> complianceByStatus =
                complianceRepository.countGroupedByStatus().stream()
                        .collect(Collectors.toMap(
                                row -> row[0].toString(),
                                row -> (Long) row[1]));

        Map<String, Long> auditBreakdown =
                auditLogRepository.countGroupedByAction().stream()
                        .collect(Collectors.toMap(
                                row -> row[0].toString(),
                                row -> (Long) row[1]));

        double avgCompletion = enrollmentRepository.findAll().stream()
                .mapToDouble(e -> e.getCompletionPercentage() != null
                        ? e.getCompletionPercentage() : 0.0)
                .average().orElse(0.0);

        return DashboardResponse.builder()
                .totalStudents(studentRepository.count())
                .totalCourses(courseRepository.count())
                .publishedCourses(
                        courseRepository.findByStatus(
                                com.cognizant.educonnect.entity.Course.CourseStatus.PUBLISHED).size())
                .totalEnrollments(enrollmentRepository.count())
                .completedEnrollments(enrollmentRepository.countCompleted())
                .totalAssessments(assessmentRepository.count())
                .gradedSubmissions(submissionRepository.countGraded())
                .pendingComplianceIssues(complianceRepository.countPending())
                .escalatedComplianceIssues(complianceRepository.countEscalated())
                .complianceByStatus(complianceByStatus)
                .auditActionsLast24h(
                        auditLogRepository.countSince(LocalDateTime.now().minusHours(24)))
                .auditActionBreakdown(auditBreakdown)
                .avgCourseCompletion(avgCompletion)
                .generatedAt(LocalDateTime.now())
                .build();
    }

    // ── Generate and persist ──────────────────────────────────────
    @Override
    @Transactional
    public ReportResponse generateAndSave(Report.ReportScope scope,
                                           Long generatedByUserId) {
        User generator = userRepository.findById(generatedByUserId)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "User not found: " + generatedByUserId));

        Map<String, Object> metrics = buildMetrics(scope);
        String metricsJson;
        try {
            metricsJson = objectMapper.writeValueAsString(metrics);
        } catch (JsonProcessingException e) {
            log.error("Failed to serialise metrics", e);
            metricsJson = "{}";
        }

        Report report = Report.builder()
                .scope(scope)
                .title(scope.name() + " Report — " + LocalDateTime.now())
                .metricsJson(metricsJson)
                .generatedBy(generator)
                .build();

        return toResponse(reportRepository.save(report));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReportResponse> getAll() {
        return reportRepository.findAllByOrderByGeneratedAtDesc()
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<ReportResponse> getByScope(Report.ReportScope scope) {
        return reportRepository.findByScope(scope)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public ReportResponse getById(Long id) {
        return toResponse(reportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Report not found: " + id)));
    }

    // ── Scoped metrics builder ────────────────────────────────────
    private Map<String, Object> buildMetrics(Report.ReportScope scope) {
        Map<String, Object> m = new HashMap<>();
        m.put("scope", scope.name());
        m.put("generatedAt", LocalDateTime.now().toString());

        switch (scope) {
            case STUDENT -> {
                m.put("total", studentRepository.count());
                m.put("active", studentRepository.findAllActive().size());
            }
            case COURSE -> {
                m.put("total", courseRepository.count());
                m.put("published", courseRepository.findByStatus(
                        com.cognizant.educonnect.entity.Course.CourseStatus.PUBLISHED).size());
            }
            case ENROLLMENT -> {
                m.put("total", enrollmentRepository.count());
                m.put("completed", enrollmentRepository.countCompleted());
            }
            case ASSESSMENT -> {
                m.put("total", assessmentRepository.count());
                m.put("gradedSubmissions", submissionRepository.countGraded());
            }
            case COMPLIANCE -> {
                m.put("pending", complianceRepository.countPending());
                m.put("escalated", complianceRepository.countEscalated());
            }
            case DASHBOARD -> {
                DashboardResponse d = getDashboard();
                m.put("totalStudents", d.getTotalStudents());
                m.put("totalCourses", d.getTotalCourses());
                m.put("totalEnrollments", d.getTotalEnrollments());
                m.put("pendingCompliance", d.getPendingComplianceIssues());
            }
        }
        return m;
    }

    // ── Mapper ────────────────────────────────────────────────────
    private ReportResponse toResponse(Report r) {
        return ReportResponse.builder()
                .id(r.getId())
                .scope(r.getScope())
                .title(r.getTitle())
                .metricsJson(r.getMetricsJson())
                .generatedById(r.getGeneratedBy() != null
                        ? r.getGeneratedBy().getId() : null)
                .generatedByName(r.getGeneratedBy() != null
                        ? r.getGeneratedBy().getFullName() : "SYSTEM")
                .generatedAt(r.getGeneratedAt())
                .build();
    }
}
