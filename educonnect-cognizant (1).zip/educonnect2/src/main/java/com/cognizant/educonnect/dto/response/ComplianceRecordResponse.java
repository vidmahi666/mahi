package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.ComplianceRecord;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class ComplianceRecordResponse {
    private Long id;
    private ComplianceRecord.EntityType entityType;
    private Long entityId;
    private String policyReference;
    private String description;
    private ComplianceRecord.ComplianceStatus status;
    private Long raisedById;
    private String raisedByName;
    private String resolution;
    private LocalDateTime resolvedAt;
    private LocalDateTime createdAt;
}
