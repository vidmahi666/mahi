package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.ContentRequest;
import com.cognizant.educonnect.dto.response.ContentResponse;
import com.cognizant.educonnect.entity.Content;
import com.cognizant.educonnect.entity.Course;
import com.cognizant.educonnect.exception.BadRequestException;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.ContentRepository;
import com.cognizant.educonnect.repository.CourseRepository;
import com.cognizant.educonnect.service.ContentService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.util.StringUtils;

import java.util.List;

@Service
@RequiredArgsConstructor
public class ContentServiceImpl implements ContentService {

    private final ContentRepository contentRepository;
    private final CourseRepository  courseRepository;

    @Override
    @Transactional
    public ContentResponse upload(ContentRequest request) {
        // ── Validate fileUri is non-empty and well-formed ──────────
        validateFileUri(request.getFileUri());

        // ── Prevent exact-duplicate URI within same course ─────────
        if (contentRepository.existsByFileUri(request.getFileUri())) {
            throw new BadRequestException(
                    "A content item with this file URI already exists");
        }

        Course course = courseRepository.findById(request.getCourseId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course not found: " + request.getCourseId()));

        Content content = Content.builder()
                .course(course)
                .title(request.getTitle())
                .type(request.getType())
                .fileUri(request.getFileUri())
                .description(request.getDescription())
                .sortOrder(request.getSortOrder())
                .build();

        return toResponse(contentRepository.save(content));
    }

    @Override
    @Transactional(readOnly = true)
    public ContentResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<ContentResponse> getByCourse(Long courseId) {
        return contentRepository
                .findByCourseIdAndStatus(courseId, Content.ContentStatus.ACTIVE)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public ContentResponse update(Long id, ContentRequest request) {
        validateFileUri(request.getFileUri());
        Content content = findOrThrow(id);
        content.setTitle(request.getTitle());
        content.setType(request.getType());
        content.setFileUri(request.getFileUri());
        content.setDescription(request.getDescription());
        content.setSortOrder(request.getSortOrder());
        return toResponse(contentRepository.save(content));
    }

    @Override
    @Transactional
    public void archive(Long id) {
        Content content = findOrThrow(id);
        content.setStatus(Content.ContentStatus.ARCHIVED);
        contentRepository.save(content);
    }

    // ── Helpers ───────────────────────────────────────────────────
    private void validateFileUri(String uri) {
        if (!StringUtils.hasText(uri)) {
            throw new BadRequestException("File URI must not be blank");
        }
        // Accept http/https URLs, s3://, or relative paths
        if (!uri.startsWith("http://")
                && !uri.startsWith("https://")
                && !uri.startsWith("s3://")
                && !uri.startsWith("/")) {
            throw new BadRequestException(
                    "Invalid file URI format. Must be an http/https URL, s3:// URI, or absolute path.");
        }
    }

    private Content findOrThrow(Long id) {
        return contentRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Content not found: " + id));
    }

    private ContentResponse toResponse(Content c) {
        return ContentResponse.builder()
                .id(c.getId())
                .courseId(c.getCourse().getId())
                .courseTitle(c.getCourse().getTitle())
                .title(c.getTitle())
                .type(c.getType())
                .fileUri(c.getFileUri())
                .description(c.getDescription())
                .sortOrder(c.getSortOrder())
                .status(c.getStatus())
                .uploadedAt(c.getUploadedAt())
                .build();
    }
}
