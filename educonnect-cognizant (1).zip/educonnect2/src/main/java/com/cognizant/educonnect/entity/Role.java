package com.cognizant.educonnect.entity;

public enum Role {
    STUDENT, TEACHER, ADMIN, MANAGER, COMPLIANCE, AUDITOR
}
