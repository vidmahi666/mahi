package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.request.ContentRequest;
import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.ContentResponse;
import com.cognizant.educonnect.service.ContentService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/content")
@RequiredArgsConstructor
@Tag(name = "Content", description = "Digital learning content management")
@SecurityRequirement(name = "Bearer Authentication")
public class ContentController {

    private final ContentService contentService;

    @PostMapping
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Upload content (stores file URI, not the binary)")
    public ResponseEntity<ApiResponse<ContentResponse>> upload(
            @Valid @RequestBody ContentRequest request) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(contentService.upload(request), "Content uploaded"));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get content by ID")
    public ResponseEntity<ApiResponse<ContentResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                contentService.getById(id), "Content retrieved"));
    }

    @GetMapping("/course/{courseId}")
    @Operation(summary = "Get all active content for a course")
    public ResponseEntity<ApiResponse<List<ContentResponse>>> getByCourse(
            @PathVariable Long courseId) {
        return ResponseEntity.ok(ApiResponse.success(
                contentService.getByCourse(courseId), "Content list retrieved"));
    }

    @PutMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Update content metadata or file URI")
    public ResponseEntity<ApiResponse<ContentResponse>> update(
            @PathVariable Long id,
            @Valid @RequestBody ContentRequest request) {
        return ResponseEntity.ok(ApiResponse.success(
                contentService.update(id, request), "Content updated"));
    }

    @DeleteMapping("/{id}")
    @PreAuthorize("hasAnyRole('TEACHER','ADMIN')")
    @Operation(summary = "Archive content (soft delete)")
    public ResponseEntity<ApiResponse<Void>> archive(@PathVariable Long id) {
        contentService.archive(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Content archived"));
    }
}
