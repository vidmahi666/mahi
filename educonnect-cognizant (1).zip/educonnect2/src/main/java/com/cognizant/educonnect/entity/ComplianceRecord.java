package com.cognizant.educonnect.entity;

import jakarta.persistence.*;
import lombok.*;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.time.LocalDateTime;

@Entity
@Table(name = "compliance_records")
@Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder
public class ComplianceRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Which domain entity this record covers (Course, Assessment, etc.) */
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private EntityType entityType;

    /** FK to the actual entity (courseId, assessmentId, etc.) */
    @Column(nullable = false)
    private Long entityId;

    @Column(nullable = false)
    private String policyReference;

    @Column(columnDefinition = "TEXT")
    private String description;

    @Enumerated(EnumType.STRING)
    @Builder.Default
    private ComplianceStatus status = ComplianceStatus.PENDING;

    /** Officer who raised / owns this record */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "raised_by")
    private User raisedBy;

    @Column(columnDefinition = "TEXT")
    private String resolution;

    private LocalDateTime resolvedAt;

    @CreationTimestamp @Column(updatable = false)
    private LocalDateTime createdAt;

    @UpdateTimestamp
    private LocalDateTime updatedAt;

    public enum EntityType     { COURSE, ASSESSMENT, CONTENT, STUDENT, USER }
    public enum ComplianceStatus { PENDING, UNDER_REVIEW, RESOLVED, ESCALATED, CLOSED }
}
