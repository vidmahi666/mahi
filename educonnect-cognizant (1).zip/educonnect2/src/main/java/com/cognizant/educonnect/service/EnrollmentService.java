package com.cognizant.educonnect.service;

import com.cognizant.educonnect.dto.request.EnrollmentRequest;
import com.cognizant.educonnect.dto.response.EnrollmentResponse;
import com.cognizant.educonnect.entity.Enrollment;

import java.util.List;

public interface EnrollmentService {
    EnrollmentResponse enroll(EnrollmentRequest request);
    List<EnrollmentResponse> getByStudent(Long studentId);
    List<EnrollmentResponse> getByCourse(Long courseId);
    EnrollmentResponse updateStatus(Long id, Enrollment.EnrollmentStatus status);
    EnrollmentResponse updateProgress(Long id, Double percentage);
    void unenroll(Long id);
}
