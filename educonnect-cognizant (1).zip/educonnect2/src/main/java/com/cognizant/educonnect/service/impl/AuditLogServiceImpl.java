package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.response.AuditLogResponse;
import com.cognizant.educonnect.entity.AuditLog;
import com.cognizant.educonnect.entity.ComplianceRecord;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.repository.AuditLogRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.AuditLogService;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
@RequiredArgsConstructor
public class AuditLogServiceImpl implements AuditLogService {

    private final AuditLogRepository auditLogRepository;
    private final UserRepository     userRepository;

    @Override
    @Transactional
    public AuditLogResponse log(Long userId, AuditLog.AuditAction action,
                                 ComplianceRecord.EntityType entityType,
                                 Long entityId, String detail, String ipAddress) {
        User user = userRepository.findById(userId).orElse(null);

        AuditLog log = AuditLog.builder()
                .performedBy(user)
                .action(action)
                .entityType(entityType)
                .entityId(entityId)
                .detail(detail)
                .ipAddress(ipAddress)
                .build();

        return toResponse(auditLogRepository.save(log));
    }

    @Override
    @Transactional(readOnly = true)
    public Page<AuditLogResponse> getByUser(Long userId, Pageable pageable) {
        return auditLogRepository.findByPerformedById(userId, pageable)
                .map(this::toResponse);
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogResponse> getByEntity(
            ComplianceRecord.EntityType type, Long entityId) {
        return auditLogRepository.findByEntityTypeAndEntityId(type, entityId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogResponse> getByDateRange(
            LocalDateTime from, LocalDateTime to) {
        return auditLogRepository.findByDateRange(from, to)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<AuditLogResponse> getAll() {
        return auditLogRepository.findAll().stream().map(this::toResponse).toList();
    }

    // ── Helpers ───────────────────────────────────────────────────
    private AuditLogResponse toResponse(AuditLog a) {
        return AuditLogResponse.builder()
                .id(a.getId())
                .performedById(a.getPerformedBy() != null
                        ? a.getPerformedBy().getId() : null)
                .performedByName(a.getPerformedBy() != null
                        ? a.getPerformedBy().getFullName() : "SYSTEM")
                .action(a.getAction())
                .entityType(a.getEntityType())
                .entityId(a.getEntityId())
                .detail(a.getDetail())
                .ipAddress(a.getIpAddress())
                .performedAt(a.getPerformedAt())
                .build();
    }
}
