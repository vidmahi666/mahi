package com.cognizant.educonnect.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

import java.time.LocalDate;

@Data
public class StudentRequest {
    @NotBlank(message = "Name is required")
    private String name;
    private LocalDate dateOfBirth;
    private String gender;
    private String address;
    private String phone;
}
