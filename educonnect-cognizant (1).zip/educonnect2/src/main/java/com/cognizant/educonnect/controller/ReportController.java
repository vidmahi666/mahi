package com.cognizant.educonnect.controller;

import com.cognizant.educonnect.dto.response.ApiResponse;
import com.cognizant.educonnect.dto.response.DashboardResponse;
import com.cognizant.educonnect.dto.response.ReportResponse;
import com.cognizant.educonnect.entity.Report;
import com.cognizant.educonnect.service.ReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
@Tag(name = "Reports & Dashboard", description = "Governance reporting and analytics")
@SecurityRequirement(name = "Bearer Authentication")
public class ReportController {

    private final ReportService reportService;

    @GetMapping("/dashboard")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Live dashboard — aggregated metrics from all modules")
    public ResponseEntity<ApiResponse<DashboardResponse>> getDashboard() {
        return ResponseEntity.ok(ApiResponse.success(
                reportService.getDashboard(), "Dashboard metrics retrieved"));
    }

    @PostMapping("/generate")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Generate and persist a scoped report snapshot")
    public ResponseEntity<ApiResponse<ReportResponse>> generate(
            @RequestParam Report.ReportScope scope,
            @RequestParam Long generatedByUserId) {
        return ResponseEntity.status(HttpStatus.CREATED).body(
                ApiResponse.success(
                        reportService.generateAndSave(scope, generatedByUserId),
                        "Report generated"));
    }

    @GetMapping
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','COMPLIANCE','AUDITOR')")
    @Operation(summary = "List all generated reports")
    public ResponseEntity<ApiResponse<List<ReportResponse>>> getAll() {
        return ResponseEntity.ok(ApiResponse.success(
                reportService.getAll(), "Reports retrieved"));
    }

    @GetMapping("/{id}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Get a specific report by ID")
    public ResponseEntity<ApiResponse<ReportResponse>> getById(@PathVariable Long id) {
        return ResponseEntity.ok(ApiResponse.success(
                reportService.getById(id), "Report retrieved"));
    }

    @GetMapping("/scope/{scope}")
    @PreAuthorize("hasAnyRole('ADMIN','MANAGER','COMPLIANCE','AUDITOR')")
    @Operation(summary = "Filter reports by scope")
    public ResponseEntity<ApiResponse<List<ReportResponse>>> getByScope(
            @PathVariable Report.ReportScope scope) {
        return ResponseEntity.ok(ApiResponse.success(
                reportService.getByScope(scope), "Reports retrieved"));
    }
}
