package com.cognizant.educonnect.dto.response;

import com.cognizant.educonnect.entity.Report;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data @Builder
public class ReportResponse {
    private Long id;
    private Report.ReportScope scope;
    private String title;
    private String metricsJson;
    private Long generatedById;
    private String generatedByName;
    private LocalDateTime generatedAt;
}
