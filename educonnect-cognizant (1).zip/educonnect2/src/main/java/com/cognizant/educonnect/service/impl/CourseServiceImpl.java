package com.cognizant.educonnect.service.impl;

import com.cognizant.educonnect.dto.request.CourseRequest;
import com.cognizant.educonnect.dto.response.CourseResponse;
import com.cognizant.educonnect.entity.Course;
import com.cognizant.educonnect.entity.User;
import com.cognizant.educonnect.exception.ResourceNotFoundException;
import com.cognizant.educonnect.repository.CourseRepository;
import com.cognizant.educonnect.repository.UserRepository;
import com.cognizant.educonnect.service.CourseService;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;

@Service
@RequiredArgsConstructor
public class CourseServiceImpl implements CourseService {

    private final CourseRepository courseRepository;
    private final UserRepository   userRepository;

    @Override
    @Transactional
    public CourseResponse create(CourseRequest request) {
        User teacher = userRepository.findById(request.getTeacherId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Teacher not found: " + request.getTeacherId()));

        Course course = Course.builder()
                .title(request.getTitle())
                .description(request.getDescription())
                .teacher(teacher)
                .startDate(request.getStartDate())
                .endDate(request.getEndDate())
                .build();

        return toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional(readOnly = true)
    public CourseResponse getById(Long id) {
        return toResponse(findOrThrow(id));
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> getAll() {
        return courseRepository.findAll().stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> getByTeacher(Long teacherId) {
        return courseRepository.findByTeacherId(teacherId)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional(readOnly = true)
    public List<CourseResponse> search(String keyword) {
        return courseRepository.searchByTitle(keyword)
                .stream().map(this::toResponse).toList();
    }

    @Override
    @Transactional
    public CourseResponse update(Long id, CourseRequest request) {
        Course course = findOrThrow(id);
        User teacher = userRepository.findById(request.getTeacherId())
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Teacher not found: " + request.getTeacherId()));
        course.setTitle(request.getTitle());
        course.setDescription(request.getDescription());
        course.setTeacher(teacher);
        course.setStartDate(request.getStartDate());
        course.setEndDate(request.getEndDate());
        return toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional
    public CourseResponse updateStatus(Long id, Course.CourseStatus status) {
        Course course = findOrThrow(id);
        course.setStatus(status);
        return toResponse(courseRepository.save(course));
    }

    @Override
    @Transactional
    public void delete(Long id) {
        Course course = findOrThrow(id);
        course.setStatus(Course.CourseStatus.ARCHIVED);
        courseRepository.save(course);
    }

    // ── Helpers ───────────────────────────────────────────────────
    private Course findOrThrow(Long id) {
        return courseRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException(
                        "Course not found: " + id));
    }

    private CourseResponse toResponse(Course c) {
        return CourseResponse.builder()
                .id(c.getId())
                .title(c.getTitle())
                .description(c.getDescription())
                .teacherId(c.getTeacher().getId())
                .teacherName(c.getTeacher().getFullName())
                .startDate(c.getStartDate())
                .endDate(c.getEndDate())
                .status(c.getStatus())
                .enrollmentCount(courseRepository.countEnrollments(c.getId()))
                .createdAt(c.getCreatedAt())
                .build();
    }
}
